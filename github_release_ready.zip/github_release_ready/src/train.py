"""
训练与评估模块 - 用于图像文本匹配任务
"""

import os
import json
import time
import argparse
import numpy as np
from tqdm import tqdm
import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim.lr_scheduler import CosineAnnealingLR
from torch.utils.tensorboard import SummaryWriter

from model_architecture import create_model
from dataset import create_dataloaders
from utils import AverageMeter, compute_metrics, save_checkpoint, load_checkpoint, contrastive_loss

def train_epoch(model, train_loader, optimizer, device, epoch, writer=None, temperature=0.07):
    """
    训练一个epoch

    参数:
        model: 模型
        train_loader: 训练数据加载器
        optimizer: 优化器
        device: 设备
        epoch: 当前epoch
        writer: TensorBoard写入器
        temperature: 对比损失中的温度参数

    返回:
        avg_loss: 平均损失
    """
    model.train()
    loss_meter = AverageMeter()
    
    # 使用tqdm显示进度条
    pbar = tqdm(train_loader, desc=f"Epoch {epoch} [Train]")
    
    for batch_idx, batch in enumerate(pbar):
        # 获取数据
        images = batch['image'].to(device)
        input_ids = batch['input_ids'].to(device)
        attention_mask = batch['attention_mask'].to(device)
        
        # 前向传播：模型返回图像和文本嵌入
        image_embeddings, text_embeddings = model(images, input_ids, attention_mask)
        
        # 计算批次内负样本的对比损失
        loss = contrastive_loss(image_embeddings, text_embeddings, temperature)
        
        # 反向传播和优化
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        # 更新损失计量器
        loss_meter.update(loss.item(), images.size(0))
        
        # 更新进度条
        pbar.set_postfix({'loss': loss_meter.avg})
        
        # 记录到TensorBoard
        if writer is not None and batch_idx % 10 == 0:
            global_step = epoch * len(train_loader) + batch_idx
            writer.add_scalar('train/loss', loss.item(), global_step)
    
    pbar.close()
    return loss_meter.avg

def validate(model, val_loader, device, epoch, writer=None):
    """
    验证模型

    参数:
        model: 模型
        val_loader: 验证数据加载器
        device: 设备
        epoch: 当前epoch
        writer: TensorBoard写入器

    返回:
        metrics: 评估指标
    """
    model.eval()
    
    # 收集所有图像和文本嵌入，以及类别信息（直接使用 metadata 中的 category 字段）
    all_image_embeddings = []
    all_text_embeddings = []
    all_categories = []

    pbar = tqdm(val_loader, desc=f"Epoch {epoch} [Val]")

    with torch.no_grad():
        for batch in pbar:
            images = batch['image'].to(device)
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            # 此处直接使用 dataset 返回的 category 字段
            categories = batch['category']

            image_embeddings, text_embeddings = model(images, input_ids, attention_mask)

            all_image_embeddings.append(image_embeddings.cpu())
            all_text_embeddings.append(text_embeddings.cpu())
            all_categories.extend(categories)

    pbar.close()

    all_image_embeddings = torch.cat(all_image_embeddings, dim=0)
    all_text_embeddings = torch.cat(all_text_embeddings, dim=0)

    metrics = compute_metrics(all_image_embeddings, all_text_embeddings, all_categories)

    if writer is not None:
        for metric_name, metric_value in metrics.items():
            writer.add_scalar(f'val/{metric_name}', metric_value, epoch)

    return metrics

def test(model, test_loader, device, output_dir):
    """
    测试模型

    参数:
        model: 模型
        test_loader: 测试数据加载器
        device: 设备
        output_dir: 输出目录

    返回:
        metrics: 评估指标
    """
    model.eval()

    all_image_embeddings = []
    all_text_embeddings = []
    all_categories = []
    all_image_paths = []
    all_captions = []

    pbar = tqdm(test_loader, desc="Testing")

    with torch.no_grad():
        for batch in pbar:
            images = batch['image'].to(device)
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            categories = batch['category']
            image_paths = batch['image_path']
            captions = batch['caption']

            image_embeddings, text_embeddings = model(images, input_ids, attention_mask)

            all_image_embeddings.append(image_embeddings.cpu())
            all_text_embeddings.append(text_embeddings.cpu())
            all_categories.extend(categories)
            all_image_paths.extend(image_paths)
            all_captions.extend(captions)

    pbar.close()

    all_image_embeddings = torch.cat(all_image_embeddings, dim=0)
    all_text_embeddings = torch.cat(all_text_embeddings, dim=0)

    metrics = compute_metrics(all_image_embeddings, all_text_embeddings, all_categories)

    test_results = {
        'metrics': metrics,
        'examples': []
    }

    # 计算相似度矩阵
    similarity_matrix = torch.matmul(all_image_embeddings, all_text_embeddings.t())

    # 对每个图像找出前5个最匹配的文本描述
    for i in range(min(len(all_image_paths), 100)):
        image_path = all_image_paths[i]
        true_caption = all_captions[i]
        
        _, indices = torch.topk(similarity_matrix[i], k=5)
        top_captions = [all_captions[idx] for idx in indices.tolist()]
        
        test_results['examples'].append({
            'image_path': image_path,
            'true_caption': true_caption,
            'top_captions': top_captions,
            'top_similarities': similarity_matrix[i][indices].tolist()
        })
    
    os.makedirs(output_dir, exist_ok=True)
    with open(os.path.join(output_dir, 'test_results.json'), 'w', encoding='utf-8') as f:
        json.dump(test_results, f, ensure_ascii=False, indent=2)
    
    return metrics

def train_model(args):
    """
    训练模型

    参数:
        args: 命令行参数
    """
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")
    
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    
    model_name = f"{args.text_model}_{args.image_model}_bs{args.batch_size}"
    output_dir = os.path.join(args.output_dir, model_name)
    os.makedirs(output_dir, exist_ok=True)
    
    writer = SummaryWriter(log_dir=os.path.join(output_dir, 'logs'))
    
    train_loader, val_loader, test_loader = create_dataloaders(
        args.processed_data_path,
        text_model_type=args.text_model,
        image_model_type=args.image_model,
        batch_size=args.batch_size,
        num_workers=args.num_workers
    )
    
    model = create_model(
        embed_dim=args.embed_dim,
        image_model_type=args.image_model,
        text_model_type=args.text_model
    )
    model = model.to(device)
    
    optimizer = optim.AdamW(
        model.parameters(),
        lr=args.learning_rate,
        weight_decay=args.weight_decay
    )
    
    scheduler = CosineAnnealingLR(
        optimizer,
        T_max=args.epochs,
        eta_min=args.learning_rate * 0.01
    )
    
    start_epoch = 0
    best_metric = 0
    if args.resume:
        start_epoch, best_metric = load_checkpoint(args.resume, model, optimizer, scheduler)
        print(f"Resumed from checkpoint: {args.resume}")
        print(f"Start epoch: {start_epoch}, Best metric: {best_metric:.4f}")
    
    print(f"Starting training for {args.epochs} epochs...")
    for epoch in range(start_epoch, args.epochs):
        train_loss = train_epoch(model, train_loader, optimizer, device, epoch, writer, temperature=0.07)
        val_metrics = validate(model, val_loader, device, epoch, writer)
        
        scheduler.step()
        
        print(f"Epoch {epoch}: Train Loss: {train_loss:.4f}, "
              f"Val Recall@1: {val_metrics['recall@1']:.4f}, "
              f"Val MRR: {val_metrics['mrr']:.4f}, "
              f"Val mAP: {val_metrics['mAP']:.4f}")
        
        current_metric = val_metrics['recall@1']
        is_best = current_metric > best_metric
        if is_best:
            best_metric = current_metric
        
        save_checkpoint({
            'epoch': epoch + 1,
            'state_dict': model.state_dict(),
            'optimizer': optimizer.state_dict(),
            'scheduler': scheduler.state_dict(),
            'best_metric': best_metric,
            'args': vars(args)
        }, is_best, output_dir)
        
        if (epoch + 1) % 10 == 0:
            save_checkpoint({
                'epoch': epoch + 1,
                'state_dict': model.state_dict(),
                'optimizer': optimizer.state_dict(),
                'scheduler': scheduler.state_dict(),
                'best_metric': best_metric,
                'args': vars(args)
            }, False, output_dir, filename=f'checkpoint_epoch{epoch+1}.pth.tar')
    
    writer.close()
    
    best_checkpoint = os.path.join(output_dir, 'model_best.pth.tar')
    if os.path.isfile(best_checkpoint):
        print(f"Loading best model from {best_checkpoint}")
        checkpoint = torch.load(best_checkpoint, map_location=device)
        model.load_state_dict(checkpoint['state_dict'])
    
    print("Testing best model...")
    test_metrics = test(model, test_loader, device, output_dir)
    
    print("Test Results:")
    for metric_name, metric_value in test_metrics.items():
        print(f"{metric_name}: {metric_value:.4f}")
    
    final_results = {
        'model_name': model_name,
        'args': vars(args),
        'test_metrics': test_metrics
    }
    
    with open(os.path.join(output_dir, 'final_results.json'), 'w', encoding='utf-8') as f:
        json.dump(final_results, f, ensure_ascii=False, indent=2)
    
    print(f"Training completed. Results saved to {output_dir}")
    
    return final_results

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='图像文本匹配训练')
    
    # 数据参数
    parser.add_argument('--processed_data_path', type=str, required=True, help='处理后的数据路径')
    
    # 模型参数
    parser.add_argument('--text_model', type=str, default='roberta', choices=['bert', 'roberta', 'distilbert'], help='文本模型类型')
    parser.add_argument('--image_model', type=str, default='efficientnet_b4', choices=['resnet50', 'resnext50_32x4d', 'efficientnet_b4'], help='图像模型类型')
    parser.add_argument('--embed_dim', type=int, default=512, help='嵌入维度')
    
    # 训练参数
    parser.add_argument('--batch_size', type=int, default=64, choices=[32, 64], help='批量大小')
    parser.add_argument('--epochs', type=int, default=80, help='训练轮数')
    parser.add_argument('--learning_rate', type=float, default=1e-4, help='学习率')
    parser.add_argument('--weight_decay', type=float, default=0.01, help='权重衰减')
    parser.add_argument('--num_workers', type=int, default=4, help='数据加载器工作线程数')
    
    # 其他参数
    parser.add_argument('--device', type=str, default='cuda:0', help='设备')
    parser.add_argument('--output_dir', type=str, default='results', help='输出目录')
    parser.add_argument('--seed', type=int, default=42, help='随机种子')
    parser.add_argument('--resume', type=str, default='', help='恢复训练的检查点路径')
    
    args = parser.parse_args()
    
    train_model(args)

if __name__ == "__main__":
    main()
