"""
数据集模块 - 用于图像文本匹配任务
"""

import os
import json
import torch
from PIL import Image
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from transformers import AutoTokenizer

class ImageTextDataset(Dataset):
    def __init__(self, metadata_path, text_model_type='roberta', max_length=128, transform=None):
        """
        图像文本数据集
        
        参数:
            metadata_path: 元数据JSON文件路径
            text_model_type: 文本模型类型 ('bert', 'roberta', 'distilbert')
            max_length: 文本最大长度
            transform: 图像变换
        """
        self.metadata_path = metadata_path
        self.max_length = max_length
        
        # 加载元数据（元数据中已包含 image_path, image_filename, captions 和 category 信息）
        with open(metadata_path, 'r', encoding='utf-8') as f:
            self.metadata = json.load(f)

        # 设置图像变换
        if transform is None:
            self.transform = transforms.Compose([
                transforms.ToTensor(),
                transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                     std=[0.229, 0.224, 0.225])
            ])
        else:
            self.transform = transform

        # 设置文本分词器
        if text_model_type == 'bert':
            self.tokenizer = AutoTokenizer.from_pretrained('bert-base-uncased')
        elif text_model_type == 'roberta':
            self.tokenizer = AutoTokenizer.from_pretrained('roberta-base')
        else:  # distilbert
            self.tokenizer = AutoTokenizer.from_pretrained('distilbert-base-uncased')

    def __len__(self):
        """返回数据集大小"""
        return len(self.metadata)

    def __getitem__(self, idx):
        """获取数据集项"""
        item = self.metadata[idx]

        # 加载图像
        image_path = item['image_path']
        image = Image.open(image_path).convert('RGB')

        # 应用变换
        if self.transform:
            image = self.transform(image)

        # 随机选择一个描述（若有多个描述则随机选一个）
        captions = item['captions']
        caption = captions[0]  # 默认使用第一个描述
        if len(captions) > 1 and torch.rand(1).item() > 0.5:
            caption = captions[1]

        # 分词
        encoding = self.tokenizer(
            caption,
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )

        # 提取 input_ids 和 attention_mask
        input_ids = encoding['input_ids'].squeeze(0)
        attention_mask = encoding['attention_mask'].squeeze(0)

        # 直接使用元数据中提供的类别信息
        category = item.get('category', 'unknown')

        return {
            'image': image,
            'input_ids': input_ids,
            'attention_mask': attention_mask,
            'caption': caption,
            'image_path': image_path,
            'category': category
        }

def get_transforms(image_model_type='efficientnet_b4', is_training=True):
    """
    获取图像变换

    参数:
        image_model_type: 图像模型类型
        is_training: 是否用于训练

    返回:
        transform: 图像变换
    """
    # 根据模型类型设置图像大小
    if image_model_type == 'efficientnet_b4':
        image_size = 380
    else:  # resnet50 或 resnext50_32x4d
        image_size = 224

    if is_training:
        transform = transforms.Compose([
            transforms.RandomResizedCrop(image_size, scale=(0.8, 1.0)),
            transforms.RandomHorizontalFlip(),
            transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                 std=[0.229, 0.224, 0.225])
        ])
    else:
        transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                 std=[0.229, 0.224, 0.225])
        ])

    return transform

def create_dataloaders(processed_data_path, text_model_type='roberta', image_model_type='efficientnet_b4',
                       batch_size=64, num_workers=4):
    """
    创建数据加载器

    参数:
        processed_data_path: 处理后的数据路径
        text_model_type: 文本模型类型
        image_model_type: 图像模型类型
        batch_size: 批量大小
        num_workers: 工作线程数

    返回:
        train_loader: 训练数据加载器
        val_loader: 验证数据加载器
        test_loader: 测试数据加载器
    """
    # 获取图像变换
    train_transform = get_transforms(image_model_type, is_training=True)
    val_transform = get_transforms(image_model_type, is_training=False)
    
    # 创建数据集
    train_dataset = ImageTextDataset(
        os.path.join(processed_data_path, 'train_metadata.json'),
        text_model_type=text_model_type,
        transform=train_transform
    )
    
    val_dataset = ImageTextDataset(
        os.path.join(processed_data_path, 'val_metadata.json'),
        text_model_type=text_model_type,
        transform=val_transform
    )
    
    test_dataset = ImageTextDataset(
        os.path.join(processed_data_path, 'test_metadata.json'),
        text_model_type=text_model_type,
        transform=val_transform
    )
    
    # 创建数据加载器
    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=True
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True
    )
    
    test_loader = DataLoader(
        test_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True
    )
    
    return train_loader, val_loader, test_loader
