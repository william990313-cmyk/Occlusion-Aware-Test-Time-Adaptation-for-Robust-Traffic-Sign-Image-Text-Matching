"""
模型架构模块 - 用于图像文本匹配任务
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import timm
from transformers import BertModel, RobertaModel, DistilBertModel

class ImageEncoder(nn.Module):
    def __init__(self, embed_dim=512, model_type='efficientnet_b4'):
        """
        图像编码器

        参数:
            embed_dim: 嵌入维度
            model_type: 模型类型 ('resnet50', 'resnext50_32x4d', 'efficientnet_b4')
        """
        super(ImageEncoder, self).__init__()

        # 根据模型类型选择骨干网络
        if model_type == 'resnet50':
            self.backbone = timm.create_model('resnet50', pretrained=True)
            self.backbone_dim = 2048
        elif model_type == 'resnext50_32x4d':
            self.backbone = timm.create_model('resnext50_32x4d', pretrained=True)
            self.backbone_dim = 2048
        else:  # efficientnet_b4
            self.backbone = timm.create_model('efficientnet_b4', pretrained=True)
            self.backbone_dim = 1792

        # 移除分类器层，根据模型结构不同进行调整
        # 如果模型有fc属性，则置为Identity，否则检查classifier属性
        if hasattr(self.backbone, 'fc'):
            self.backbone.fc = nn.Identity()
        elif hasattr(self.backbone, 'classifier'):
            self.backbone.classifier = nn.Identity()

        # 特征投影层
        self.projection = nn.Linear(self.backbone_dim, embed_dim)
        self.norm = nn.LayerNorm(embed_dim)

    def forward(self, x):
        """前向传播"""
        # 提取特征
        features = self.backbone(x)
        # 投影到嵌入空间
        embeddings = self.projection(features)
        embeddings = self.norm(embeddings)
        # 归一化
        embeddings = F.normalize(embeddings, p=2, dim=1)
        return embeddings

class TextEncoder(nn.Module):
    def __init__(self, embed_dim=512, model_type='roberta'):
        """
        文本编码器

        参数:
            embed_dim: 嵌入维度
            model_type: 文本模型类型 ('bert', 'roberta', 'distilbert')
        """
        super(TextEncoder, self).__init__()

        # 根据模型类型选择预训练模型
        if model_type == 'bert':
            self.transformer = BertModel.from_pretrained('bert-base-uncased')
            self.hidden_dim = 768
        elif model_type == 'roberta':
            self.transformer = RobertaModel.from_pretrained('roberta-base')
            self.hidden_dim = 768
        else:  # distilbert
            self.transformer = DistilBertModel.from_pretrained('distilbert-base-uncased')
            self.hidden_dim = 768

        # 特征投影层
        self.projection = nn.Linear(self.hidden_dim, embed_dim)
        self.norm = nn.LayerNorm(embed_dim)

    def forward(self, input_ids, attention_mask):
        """前向传播"""
        # 提取特征
        outputs = self.transformer(input_ids=input_ids, attention_mask=attention_mask)
        # 使用[CLS]标记的输出作为句子表示
        sentence_embedding = outputs.last_hidden_state[:, 0, :]
        # 投影到嵌入空间
        embeddings = self.projection(sentence_embedding)
        embeddings = self.norm(embeddings)
        # 归一化
        embeddings = F.normalize(embeddings, p=2, dim=1)
        return embeddings

class CMPMLoss(nn.Module):
    def __init__(self, epsilon=1e-8):
        """
        Cross-Modal Projection Matching Loss

        参数:
            epsilon: 数值稳定性的小常数
        """
        super(CMPMLoss, self).__init__()
        self.epsilon = epsilon

    def forward(self, image_embeddings, text_embeddings, labels=None):
        """
        计算CMPM损失

        参数:
            image_embeddings: 图像嵌入 [batch_size, embed_dim]
            text_embeddings: 文本嵌入 [batch_size, embed_dim]
            labels: 标签 (如果为None，则假设每个图像与其对应位置的文本匹配)

        返回:
            loss: CMPM损失值
        """
        batch_size = image_embeddings.size(0)

        # 如果没有提供标签，则假设对角线匹配
        if labels is None:
            labels = torch.arange(batch_size).to(image_embeddings.device)
            text_labels = labels
        else:
            text_labels = labels

        # 计算相似度矩阵
        sim_matrix = torch.matmul(image_embeddings, text_embeddings.t())

        # 计算图像到文本的匹配概率
        i2t_pred = F.softmax(sim_matrix, dim=1)
        # 计算文本到图像的匹配概率
        t2i_pred = F.softmax(sim_matrix, dim=0)

        # 创建目标匹配矩阵
        targets = torch.zeros_like(sim_matrix)
        for i, label in enumerate(labels):
            for j, text_label in enumerate(text_labels):
                if label == text_label:
                    targets[i, j] = 1

        # 归一化目标矩阵
        targets_i2t = targets / (targets.sum(dim=1, keepdim=True) + self.epsilon)
        targets_t2i = targets / (targets.sum(dim=0, keepdim=True) + self.epsilon)

        # 计算KL散度损失
        i2t_loss = F.kl_div(torch.log(i2t_pred + self.epsilon), targets_i2t, reduction='batchmean')
        t2i_loss = F.kl_div(torch.log(t2i_pred + self.epsilon), targets_t2i, reduction='batchmean')

        # 总损失
        loss = (i2t_loss + t2i_loss) / 2

        return loss

class ImageTextMatchingModel(nn.Module):
    def __init__(self, embed_dim=512, image_model_type='efficientnet_b4', text_model_type='roberta'):
        """
        图像文本匹配模型

        参数:
            embed_dim: 嵌入维度
            image_model_type: 图像模型类型
            text_model_type: 文本模型类型
        """
        super(ImageTextMatchingModel, self).__init__()

        # 图像编码器
        self.image_encoder = ImageEncoder(embed_dim, image_model_type)

        # 文本编码器
        self.text_encoder = TextEncoder(embed_dim, text_model_type)

        # 损失函数（如果需要，可在外部调用，不在forward中计算）
        self.criterion = CMPMLoss()

    def forward(self, images, input_ids, attention_mask, labels=None):
        """
        前向传播

        参数:
            images: 图像输入
            input_ids: 文本输入ID
            attention_mask: 文本注意力掩码
            labels: 标签 (可选)

        返回:
            image_embeddings: 图像嵌入
            text_embeddings: 文本嵌入
        """
        # 获取图像嵌入
        image_embeddings = self.image_encoder(images)
        # 获取文本嵌入
        text_embeddings = self.text_encoder(input_ids, attention_mask)
        # 直接返回嵌入，不计算损失
        return image_embeddings, text_embeddings

    def get_image_embeddings(self, images):
        """获取图像嵌入"""
        return self.image_encoder(images)

    def get_text_embeddings(self, input_ids, attention_mask):
        """获取文本嵌入"""
        return self.text_encoder(input_ids, attention_mask)

# 模型工厂函数
def create_model(embed_dim=512, image_model_type='efficientnet_b4', text_model_type='roberta'):
    """
    创建图像文本匹配模型

    参数:
        embed_dim: 嵌入维度
        image_model_type: 图像模型类型 ('resnet50', 'resnext50_32x4d', 'efficientnet_b4')
        text_model_type: 文本模型类型 ('bert', 'roberta', 'distilbert')

    返回:
        model: 图像文本匹配模型
    """
    model = ImageTextMatchingModel(embed_dim, image_model_type, text_model_type)
    return model
