"""
工具函数模块 - 用于图像文本匹配任务
"""

import os
import torch
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.manifold import TSNE
from sklearn.metrics import average_precision_score
import torch.nn.functional as F

class AverageMeter:
    """计算并存储平均值和当前值"""
    def __init__(self):
        self.reset()
        
    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0
        
    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count

def contrastive_loss(image_embeddings, text_embeddings, temperature=0.07):
    """
    计算批次内负样本的对比损失（InfoNCE 损失）
    
    参数:
        image_embeddings: 图像嵌入，形状为 (batch_size, embed_dim)
        text_embeddings: 文本嵌入，形状为 (batch_size, embed_dim)
        temperature: 温度参数，用于调节相似度分布
    返回:
        loss: 对比损失值
    """
    # 确保嵌入向量归一化
    image_embeddings = F.normalize(image_embeddings, p=2, dim=1)
    text_embeddings = F.normalize(text_embeddings, p=2, dim=1)
    
    # 计算相似度矩阵，并按温度参数缩放
    sim_matrix = torch.matmul(image_embeddings, text_embeddings.t()) / temperature
    
    # 构造标签：每个正样本对对应自身的索引
    batch_size = image_embeddings.size(0)
    labels = torch.arange(batch_size).to(image_embeddings.device)
    
    # 计算图像到文本的损失
    loss_i2t = F.cross_entropy(sim_matrix, labels)
    # 计算文本到图像的损失
    loss_t2i = F.cross_entropy(sim_matrix.t(), labels)
    
    # 最终损失为两个方向损失的平均
    loss = (loss_i2t + loss_t2i) / 2
    return loss

def compute_metrics(image_embeddings, text_embeddings, categories, k_values=[1, 5, 10]):
    """
    计算评估指标

    参数:
        image_embeddings: 图像嵌入 [n, d]
        text_embeddings: 文本嵌入 [n, d]
        categories: 类别列表 [n]
        k_values: 计算Recall@K的K值列表

    返回:
        metrics: 评估指标字典
    """
    # 计算相似度矩阵
    similarity_matrix = torch.matmul(image_embeddings, text_embeddings.t())

    # 创建标签矩阵，直接比较类别字符串
    n = len(categories)
    labels = torch.zeros(n, n)
    for i, cat_i in enumerate(categories):
        for j, cat_j in enumerate(categories):
            if cat_i == cat_j:
                labels[i, j] = 1

    # 计算Recall@K
    recall_metrics = {}
    for k in k_values:
        # 图像到文本
        i2t_recall = compute_recall_at_k(similarity_matrix, labels, k)
        # 文本到图像
        t2i_recall = compute_recall_at_k(similarity_matrix.t(), labels.t(), k)
        # 平均
        avg_recall = (i2t_recall + t2i_recall) / 2
        recall_metrics[f'recall@{k}'] = avg_recall

    # 计算MRR (Mean Reciprocal Rank)
    i2t_mrr = compute_mrr(similarity_matrix, labels)
    t2i_mrr = compute_mrr(similarity_matrix.t(), labels.t())
    avg_mrr = (i2t_mrr + t2i_mrr) / 2

    # 计算mAP (mean Average Precision)
    i2t_map = compute_map(similarity_matrix, labels)
    t2i_map = compute_map(similarity_matrix.t(), labels.t())
    avg_map = (i2t_map + t2i_map) / 2

    # 汇总指标
    metrics = {
        **recall_metrics,
        'mrr': avg_mrr,
        'mAP': avg_map
    }

    return metrics

def compute_recall_at_k(similarity_matrix, labels, k):
    """
    计算Recall@K

    参数:
        similarity_matrix: 相似度矩阵 [n, n]
        labels: 标签矩阵 [n, n]
        k: K值

    返回:
        recall: Recall@K值
    """
    # 获取每行的前K个最相似项的索引
    _, indices = torch.topk(similarity_matrix, k, dim=1)

    # 检查这些索引中是否包含正确匹配
    correct = 0
    for i, idx_list in enumerate(indices):
        pred_labels = labels[i, idx_list]
        if pred_labels.sum() > 0:
            correct += 1
    recall = correct / similarity_matrix.size(0)
    return recall

def compute_mrr(similarity_matrix, labels):
    """
    计算MRR (Mean Reciprocal Rank)

    参数:
        similarity_matrix: 相似度矩阵 [n, n]
        labels: 标签矩阵 [n, n]

    返回:
        mrr: MRR值
    """
    _, indices = torch.sort(similarity_matrix, dim=1, descending=True)
    reciprocal_ranks = []
    for i, idx_list in enumerate(indices):
        for rank, idx in enumerate(idx_list):
            if labels[i, idx] > 0:
                reciprocal_ranks.append(1.0 / (rank + 1))
                break
        else:
            reciprocal_ranks.append(0.0)
    mrr = np.mean(reciprocal_ranks)
    return mrr

def compute_map(similarity_matrix, labels):
    """
    计算mAP (mean Average Precision)

    参数:
        similarity_matrix: 相似度矩阵 [n, n]
        labels: 标签矩阵 [n, n]

    返回:
        map_score: mAP值
    """
    sim_np = similarity_matrix.numpy()
    labels_np = labels.numpy()
    ap_scores = []
    for i in range(sim_np.shape[0]):
        scores = sim_np[i]
        y_true = labels_np[i]
        ap = average_precision_score(y_true, scores)
        ap_scores.append(ap)
    map_score = np.mean(ap_scores)
    return map_score

def save_checkpoint(state, is_best, output_dir, filename='checkpoint.pth.tar'):
    """
    保存检查点

    参数:
        state: 检查点状态
        is_best: 是否是最佳模型
        output_dir: 输出目录
        filename: 文件名
    """
    torch.save(state, os.path.join(output_dir, filename))
    if is_best:
        torch.save(state, os.path.join(output_dir, 'model_best.pth.tar'))

def load_checkpoint(checkpoint_path, model, optimizer=None, scheduler=None):
    """
    加载检查点

    参数:
        checkpoint_path: 检查点路径
        model: 模型
        optimizer: 优化器
        scheduler: 学习率调度器

    返回:
        epoch: 开始的epoch
        best_metric: 最佳指标
    """
    checkpoint = torch.load(checkpoint_path)
    model.load_state_dict(checkpoint['state_dict'])
    if optimizer is not None and 'optimizer' in checkpoint:
        optimizer.load_state_dict(checkpoint['optimizer'])
    if scheduler is not None and 'scheduler' in checkpoint:
        scheduler.load_state_dict(checkpoint['scheduler'])
    epoch = checkpoint.get('epoch', 0)
    best_metric = checkpoint.get('best_metric', 0.0)
    return epoch, best_metric

def plot_training_curves(train_losses, val_metrics, output_path):
    """
    绘制训练曲线

    参数:
        train_losses: 训练损失列表
        val_metrics: 验证指标字典
        output_path: 输出路径
    """
    plt.figure(figsize=(12, 8))
    plt.subplot(2, 1, 1)
    plt.plot(train_losses, 'b-', label='Training Loss')
    plt.title('Training Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.grid(True)
    plt.subplot(2, 1, 2)
    for metric_name, metric_values in val_metrics.items():
        plt.plot(metric_values, label=metric_name)
    plt.title('Validation Metrics')
    plt.xlabel('Epoch')
    plt.ylabel('Value')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()

def plot_confusion_matrix(similarity_matrix, categories, output_path, n_samples=50):
    """
    绘制相似度矩阵热图

    参数:
        similarity_matrix: 相似度矩阵
        categories: 类别列表
        output_path: 输出路径
        n_samples: 样本数量
    """
    n = min(n_samples, similarity_matrix.shape[0])
    indices = np.random.choice(similarity_matrix.shape[0], n, replace=False)
    sub_matrix = similarity_matrix[indices][:, indices].numpy()
    sub_categories = [categories[i] for i in indices]
    plt.figure(figsize=(12, 10))
    sns.heatmap(sub_matrix, cmap='viridis', xticklabels=False, yticklabels=False)
    plt.title('Similarity Matrix Heatmap')
    plt.xlabel('Text')
    plt.ylabel('Image')
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()

def plot_tsne(image_embeddings, text_embeddings, categories, output_path, n_samples=500):
    """
    绘制t-SNE可视化

    参数:
        image_embeddings: 图像嵌入
        text_embeddings: 文本嵌入
        categories: 类别列表
        output_path: 输出路径
        n_samples: 样本数量
    """
    n = min(n_samples, len(categories))
    indices = np.random.choice(len(categories), n, replace=False)
    img_emb = image_embeddings[indices].numpy()
    txt_emb = text_embeddings[indices].numpy()
    cats = [categories[i] for i in indices]
    combined_emb = np.vstack([img_emb, txt_emb])
    tsne = TSNE(n_components=2, random_state=42, perplexity=30)
    embeddings_2d = tsne.fit_transform(combined_emb)
    img_2d = embeddings_2d[:n]
    txt_2d = embeddings_2d[n:]
    plt.figure(figsize=(12, 10))
    unique_cats = list(set(cats))
    colors = plt.cm.rainbow(np.linspace(0, 1, len(unique_cats)))
    cat_to_color = {cat: colors[i] for i, cat in enumerate(unique_cats)}
    for i, (x, y) in enumerate(img_2d):
        plt.scatter(x, y, color=cat_to_color[cats[i]], marker='o', s=50, alpha=0.7)
    for i, (x, y) in enumerate(txt_2d):
        plt.scatter(x, y, color=cat_to_color[cats[i]], marker='x', s=50, alpha=0.7)
    img_patch = plt.Line2D([0], [0], marker='o', color='w', markerfacecolor='gray', markersize=10, label='Image')
    txt_patch = plt.Line2D([0], [0], marker='x', color='gray', markersize=10, label='Text')
    plt.legend(handles=[img_patch, txt_patch], loc='upper right')
    plt.title('t-SNE Visualization of Image and Text Embeddings')
    plt.xlabel('t-SNE Dimension 1')
    plt.ylabel('t-SNE Dimension 2')
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()

def plot_radar_chart(metrics_dict, output_path):
    """
    绘制雷达图

    参数:
        metrics_dict: 指标字典
        output_path: 输出路径
    """
    metrics = list(metrics_dict.keys())
    values = [metrics_dict[m] for m in metrics]
    angles = np.linspace(0, 2*np.pi, len(metrics), endpoint=False).tolist()
    values += values[:1]
    angles += angles[:1]
    metrics += metrics[:1]
    plt.figure(figsize=(10, 8))
    ax = plt.subplot(111, polar=True)
    ax.plot(angles, values, 'o-', linewidth=2)
    ax.fill(angles, values, alpha=0.25)
    ax.set_thetagrids(np.degrees(angles[:-1]), metrics[:-1])
    ax.set_ylim(0, 1)
    plt.title('Model Performance Metrics', size=15)
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()

def plot_batch_size_comparison(results_32, results_64, output_path):
    """
    绘制批量大小对比图

    参数:
        results_32: 批量大小32的结果
        results_64: 批量大小64的结果
        output_path: 输出路径
    """
    metrics = ['recall@1', 'recall@5', 'recall@10', 'mrr', 'mAP']
    values_32 = [results_32.get(m, 0) for m in metrics]
    values_64 = [results_64.get(m, 0) for m in metrics]
    x = np.arange(len(metrics))
    width = 0.35
    plt.figure(figsize=(12, 8))
    plt.bar(x - width/2, values_32, width, label='Batch Size 32')
    plt.bar(x + width/2, values_64, width, label='Batch Size 64')
    plt.xlabel('Metrics')
    plt.ylabel('Values')
    plt.title('Performance Comparison: Batch Size 32 vs 64')
    plt.xticks(x, metrics)
    plt.legend()
    for i, v in enumerate(values_32):
        plt.text(i - width/2, v + 0.01, f'{v:.4f}', ha='center')
    for i, v in enumerate(values_64):
        plt.text(i + width/2, v + 0.01, f'{v:.4f}', ha='center')
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()

def plot_model_comparison(results_dict, output_path):
    """
    绘制模型比较图

    参数:
        results_dict: 结果字典，格式为 {model_name: {metric: value}}
        output_path: 输出路径
    """
    models = list(results_dict.keys())
    metrics = ['recall@1', 'mrr', 'mAP']
    plt.figure(figsize=(15, 10))
    x = np.arange(len(models))
    width = 0.25
    offsets = [-width, 0, width]
    for i, metric in enumerate(metrics):
        values = [results_dict[model].get(metric, 0) for model in models]
        plt.bar(x + offsets[i], values, width, label=metric)
    plt.xlabel('Models')
    plt.ylabel('Values')
    plt.title('Performance Comparison Across Models')
    plt.xticks(x, models, rotation=45, ha='right')
    plt.legend()
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
