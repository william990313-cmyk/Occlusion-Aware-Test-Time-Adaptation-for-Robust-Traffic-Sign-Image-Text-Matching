# Flickr30k metric correction

The corrected evaluator ranks every candidate caption for each image query and every candidate image for each caption query.  Flickr30k uses 2,214 image queries and 11,070 caption candidates (five valid captions per image).  The rank of the first valid match is used for Recall@K.

The original duplicated `60.48` entries were traced to an invalid protocol involving ground-truth text leakage and a restricted Top-64 gate, rather than corrected image-to-text dataset-level ranking.  The values have been superseded by the corrected table in `revision_results_public/paper_ready/table_flickr30k_corrected.md`.
