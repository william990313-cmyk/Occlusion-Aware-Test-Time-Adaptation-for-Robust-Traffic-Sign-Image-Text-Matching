# Reproducibility notes

1. Keep all retrieval candidates at dataset level; do not evaluate only within minibatches.
2. Use all captions belonging to the query image as valid positives.
3. For the main test set, use 1,512 image queries and 3,024 caption candidates.
4. For the lightweight pair reranker, first obtain Top-K candidates with the dual encoder; K=5 is the smallest saturated setting in the reported sensitivity analysis.
5. The pair MLP accepts image/text embedding interactions `[v, t, |v-t|, v*t]`; it is not a text-text reranker.
6. Do not apply the ResNeXt BatchNorm TENT procedure directly to LayerNorm-only ViT backbones.
