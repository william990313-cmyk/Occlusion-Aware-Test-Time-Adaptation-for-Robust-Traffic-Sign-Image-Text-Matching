#!/usr/bin/env python3
"""Export full-image/full-caption embeddings for corrected Flickr30k metrics."""
import argparse
import json
import os
from pathlib import Path

import numpy as np
import torch
from PIL import Image
from torch.utils.data import DataLoader, Dataset
from transformers import AutoTokenizer

from model_architecture import create_model
from dataset import get_transforms


class ImageOnlyDataset(Dataset):
    def __init__(self, data_dir, metadata_path, image_model):
        self.data_dir = Path(data_dir)
        self.meta = json.loads(Path(metadata_path).read_text(encoding="utf-8"))
        self.transform = get_transforms(image_model, is_training=False)

    def __len__(self):
        return len(self.meta)

    def __getitem__(self, i):
        item = self.meta[i]
        path = self.data_dir / os.path.basename(item["image_path"])
        image = self.transform(Image.open(path).convert("RGB"))
        return image


def encode_images(model, loader, device):
    out = []
    with torch.no_grad():
        for images in loader:
            out.append(model.get_image_embeddings(images.to(device)).cpu())
    return torch.cat(out).numpy()


def encode_captions(model, meta, text_model, device, batch_size):
    captions = [c for item in meta for c in item["captions"]]
    ids = np.repeat(np.arange(len(meta), dtype=np.int64), [len(x["captions"]) for x in meta])
    tokenizer_name = {"distilbert": "distilbert-base-uncased", "roberta": "roberta-base", "bert": "bert-base-uncased"}[text_model]
    tok = AutoTokenizer.from_pretrained(tokenizer_name)
    out = []
    with torch.no_grad():
        for start in range(0, len(captions), batch_size):
            enc = tok(captions[start:start + batch_size], max_length=128,
                      padding="max_length", truncation=True, return_tensors="pt")
            out.append(model.get_text_embeddings(enc["input_ids"].to(device), enc["attention_mask"].to(device)).cpu())
    return torch.cat(out).numpy(), ids


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--checkpoint", required=True)
    p.add_argument("--data-dir", required=True, help="directory containing image files")
    p.add_argument("--metadata", required=True, help="metadata JSON for this split")
    p.add_argument("--caption-metadata", required=True, help="metadata JSON supplying all captions")
    p.add_argument("--image-model", default="resnext50_32x4d")
    p.add_argument("--text-model", default="distilbert")
    p.add_argument("--embed-dim", type=int, default=512)
    p.add_argument("--batch-size", type=int, default=64)
    p.add_argument("--num-workers", type=int, default=2)
    p.add_argument("--device", default="cuda:0")
    p.add_argument("--output-prefix", required=True)
    args = p.parse_args()
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    ck = torch.load(args.checkpoint, map_location="cpu")
    saved_args = ck.get("args", {})
    model = create_model(embed_dim=saved_args.get("embed_dim", args.embed_dim),
                         image_model_type=saved_args.get("image_model", args.image_model),
                         text_model_type=saved_args.get("text_model", args.text_model)).to(device)
    model.load_state_dict(ck["state_dict"])
    model.eval()
    meta = json.loads(Path(args.metadata).read_text(encoding="utf-8"))
    cap_meta = json.loads(Path(args.caption_metadata).read_text(encoding="utf-8"))
    ds = ImageOnlyDataset(args.data_dir, args.metadata, saved_args.get("image_model", args.image_model))
    loader = DataLoader(ds, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers)
    image = encode_images(model, loader, device)
    text, ids = encode_captions(model, cap_meta, saved_args.get("text_model", args.text_model), device, args.batch_size)
    prefix = Path(args.output_prefix)
    prefix.parent.mkdir(parents=True, exist_ok=True)
    np.save(str(prefix) + "_image_embeddings.npy", image)
    np.save(str(prefix) + "_caption_embeddings.npy", text)
    np.save(str(prefix) + "_caption_image_ids.npy", ids)
    np.save(str(prefix) + "_similarity.npy", image @ text.T)
    print("saved", image.shape, text.shape, ids.shape)


if __name__ == "__main__":
    main()
