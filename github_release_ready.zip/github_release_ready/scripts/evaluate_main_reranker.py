#!/usr/bin/env python3
import argparse, csv, json
from pathlib import Path
import numpy as np
import torch
from train_lightweight_pair_reranker import PairMLP

def score(model, v, t, device, batch=4096):
    out=[]; model.eval()
    with torch.no_grad():
        for s in range(0,len(v),batch):
            out.append(model(torch.tensor(v[s:s+batch],dtype=torch.float32,device=device), torch.tensor(t[s:s+batch],dtype=torch.float32,device=device)).cpu().numpy())
    return np.concatenate(out)

def rerank_i2t(sim, v, t, model, k, device):
    ranks=np.argsort(-sim,axis=1,kind='stable')
    out=ranks.copy()
    for i in range(len(v)):
        idx=ranks[i,:k]; s=score(model,np.repeat(v[i:i+1],k,axis=0),t[idx],device); out[i,:k]=idx[np.argsort(-s,kind='stable')]
    return out

def rerank_t2i(sim, v, t, model, k, device):
    ranks=np.argsort(-sim.T,axis=1,kind='stable'); out=ranks.copy()
    for j in range(len(t)):
        idx=ranks[j,:k]; s=score(model,v[idx],np.repeat(t[j:j+1],k,axis=0),device); out[j,:k]=idx[np.argsort(-s,kind='stable')]
    return out

def metrics(i2t,t2i,ids,nimg):
    i2t_r=[]
    for i,row in enumerate(i2t): i2t_r.append(np.flatnonzero(np.isin(ids[row],i))[0])
    t2i_r=[np.flatnonzero(row==ids[j])[0] for j,row in enumerate(t2i)]
    def r(x,k): return float(np.mean(np.asarray(x)<k)*100)
    return {'image_to_text':{f'R@{k}':r(i2t_r,k) for k in (1,5,10)},'text_to_image':{f'R@{k}':r(t2i_r,k) for k in (1,5,10)}}

def main():
    p=argparse.ArgumentParser(); p.add_argument('--image-embeddings',required=True); p.add_argument('--text-embeddings',required=True); p.add_argument('--caption-image-ids',required=True); p.add_argument('--similarity',required=True); p.add_argument('--checkpoint',required=True); p.add_argument('--output-dir',required=True); p.add_argument('--topk',type=int,default=10); p.add_argument('--device',default='cuda:0')
    a=p.parse_args(); out=Path(a.output_dir); out.mkdir(parents=True,exist_ok=True); dev=torch.device(a.device if torch.cuda.is_available() else 'cpu')
    v=np.load(a.image_embeddings); t=np.load(a.text_embeddings); ids=np.load(a.caption_image_ids); sim=np.load(a.similarity)
    ck=torch.load(a.checkpoint,map_location='cpu'); d=int(ck['embed_dim']); model=PairMLP(d).to(dev); model.load_state_dict(ck['state_dict'])
    i2t=rerank_i2t(sim,v,t,model,a.topk,dev); t2i=rerank_t2i(sim,v,t,model,a.topk,dev); result=metrics(i2t,t2i,ids,len(v)); result['topk']=a.topk; result['candidate_pool']={'images':len(v),'captions':len(t),'scope':'dataset-level'}
    (out/'metrics.json').write_text(json.dumps(result,indent=2)+'\n')
    with open(out/'topk_changes.csv','w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(['direction','query_id','before_top1','after_top1','ground_truth_in_after_top10'])
        for i in range(len(v)): w.writerow(['image_to_text',i,int(np.argsort(-sim[i],kind='stable')[0]),int(i2t[i,0]),bool(np.any(ids[i2t[i,:10]]==i))])
        for j in range(len(t)): w.writerow(['text_to_image',j,int(np.argsort(-sim[:,j],kind='stable')[0]),int(t2i[j,0]),bool(np.any(t2i[j,:10]==ids[j]))])
    print(json.dumps(result,indent=2))
if __name__=='__main__': main()
