#!/usr/bin/env python3
"""Train a lightweight genuine image-text pair scorer on exported embeddings."""
import argparse, csv, json, random
from pathlib import Path
import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

class PairMLP(nn.Module):
    def __init__(self, d):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(4*d, 512), nn.ReLU(), nn.Dropout(.1), nn.Linear(512, 1))
    def forward(self, v, t):
        return self.net(torch.cat([v, t, (v-t).abs(), v*t], dim=1)).squeeze(1)

def load_pairs(prefix, negatives, seed):
    rng = random.Random(seed)
    v = np.load(str(prefix)+"_image_embeddings.npy")
    t = np.load(str(prefix)+"_caption_embeddings.npy")
    ids = np.load(str(prefix)+"_caption_image_ids.npy")
    by_image = {i: np.flatnonzero(ids == i).tolist() for i in range(v.shape[0])}
    vv, tt, yy = [], [], []
    for i in range(v.shape[0]):
        pos = by_image[i]
        other = [j for j in range(v.shape[0]) if j != i]
        for j in pos:
            vv.append(v[i]); tt.append(t[j]); yy.append(1.)
            for neg_img in rng.sample(other, min(negatives, len(other))):
                neg_j = rng.choice(by_image[neg_img]); vv.append(v[i]); tt.append(t[neg_j]); yy.append(0.)
    return torch.tensor(np.asarray(vv), dtype=torch.float32), torch.tensor(np.asarray(tt), dtype=torch.float32), torch.tensor(yy)

def main():
    p=argparse.ArgumentParser(); p.add_argument('--train-prefix',required=True); p.add_argument('--val-prefix',required=True); p.add_argument('--output-dir',required=True); p.add_argument('--epochs',type=int,default=5); p.add_argument('--batch-size',type=int,default=512); p.add_argument('--negatives',type=int,default=4); p.add_argument('--lr',type=float,default=1e-4); p.add_argument('--seed',type=int,default=42)
    a=p.parse_args(); random.seed(a.seed); np.random.seed(a.seed); torch.manual_seed(a.seed); out=Path(a.output_dir); out.mkdir(parents=True,exist_ok=True)
    tr=load_pairs(Path(a.train_prefix),a.negatives,a.seed); va=load_pairs(Path(a.val_prefix),a.negatives,a.seed+1); d=tr[0].shape[1]; model=PairMLP(d); opt=torch.optim.Adam(model.parameters(),lr=a.lr); loss_fn=nn.BCEWithLogitsLoss(); rows=[]; best=-1
    for ep in range(1,a.epochs+1):
        model.train(); total=0
        for vb,tb,yb in DataLoader(TensorDataset(*tr),a.batch_size,shuffle=True):
            loss=loss_fn(model(vb,tb),yb); opt.zero_grad(); loss.backward(); opt.step(); total += loss.item()*len(yb)
        model.eval(); probs=[]; ys=[]
        with torch.no_grad():
            for vb,tb,yb in DataLoader(TensorDataset(*va),a.batch_size): probs.append(model(vb,tb).sigmoid()); ys.append(yb)
        pr=torch.cat(probs); y=torch.cat(ys); auc=((pr[y==1].unsqueeze(1)>pr[y==0]).float().mean().item() if (y==1).any() and (y==0).any() else 0.)
        rows.append({'epoch':ep,'train_loss':total/len(tr[2]),'val_pair_order_auc':auc}); print(rows[-1],flush=True)
        if auc>best: best=auc; torch.save({'state_dict':model.state_dict(),'embed_dim':d,'args':vars(a)},out/'best_ce_pair_mlp.pth')
    with open(out/'ce_training_log.csv','w',newline='') as f: w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
    (out/'best_ce_checkpoint_path.txt').write_text(str(out/'best_ce_pair_mlp.pth')+'\n'); (out/'ce_training_summary.md').write_text(f'Lightweight image-text pair MLP; epochs={a.epochs}, negatives={a.negatives}, best validation pair-order AUC={best:.6f}.\n')
if __name__=='__main__': main()
