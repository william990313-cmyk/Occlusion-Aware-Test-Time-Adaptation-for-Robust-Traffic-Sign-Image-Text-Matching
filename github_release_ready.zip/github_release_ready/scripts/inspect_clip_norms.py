import argparse,json,torch
import torch.nn as nn
from transformers import CLIPModel
p=argparse.ArgumentParser();p.add_argument('--model-id',default='openai/clip-vit-base-patch32');p.add_argument('--output',required=True);a=p.parse_args();m=CLIPModel.from_pretrained(a.model_id)
bn=[n for n,x in m.named_modules() if isinstance(x,nn.modules.batchnorm._BatchNorm)];ln=[n for n,x in m.named_modules() if isinstance(x,nn.LayerNorm)]
r={'model':a.model_id,'batchnorm_layers':len(bn),'layernorm_layers':len(ln),'batchnorm_names':bn,'layernorm_names':ln,'vision_norm':'LayerNorm-based ViT encoder','text_norm':'LayerNorm-based Transformer encoder','bn_tent_directly_applicable':len(bn)>0}
json.dump(r,open(a.output,'w'),indent=2);print(json.dumps(r,indent=2))
