import argparse, json, os
import numpy as np
import torch
from PIL import Image
from torchvision import transforms
from transformers import AutoTokenizer
from model_architecture import create_model

p=argparse.ArgumentParser(); p.add_argument('--data',required=True); p.add_argument('--split',required=True,choices=['train','val','test']); p.add_argument('--checkpoint',required=True); p.add_argument('--state-dict',default=None); p.add_argument('--output-prefix',required=True); p.add_argument('--batch-size',type=int,default=64); p.add_argument('--device',default='cuda:0'); p.add_argument('--save-similarity',action='store_true'); a=p.parse_args()
d=torch.device(a.device if torch.cuda.is_available() else 'cpu'); ck=torch.load(a.checkpoint,map_location='cpu'); c=ck.get('args',{})
m=create_model(embed_dim=c.get('embed_dim',512),image_model_type=c.get('image_model','resnext50_32x4d'),text_model_type=c.get('text_model','distilbert'));m.load_state_dict(ck['state_dict']);
if a.state_dict: m.load_state_dict(torch.load(a.state_dict,map_location='cpu')['state_dict'])
m.to(d).eval()
meta=json.load(open(os.path.join(a.data,f'{a.split}_metadata.json'),encoding='utf-8')); tr=transforms.Compose([transforms.Resize((224,224)),transforms.ToTensor(),transforms.Normalize([.485,.456,.406],[.229,.224,.225])]); tok=AutoTokenizer.from_pretrained('distilbert-base-uncased')
images=[]; captions=[]; ids=[]
for i,r in enumerate(meta): images.append(tr(Image.open(os.path.join(a.data,a.split,r['image_filename'])).convert('RGB'))); captions.extend(r['captions']);ids.extend([i]*len(r['captions']))
ivec=[]; tvec=[]
with torch.inference_mode():
 for j in range(0,len(images),a.batch_size): ivec.append(m.get_image_embeddings(torch.stack(images[j:j+a.batch_size]).to(d)).cpu())
 enc=tok(captions,max_length=128,padding='max_length',truncation=True,return_tensors='pt')
 for j in range(0,len(captions),a.batch_size): tvec.append(m.get_text_embeddings(enc['input_ids'][j:j+a.batch_size].to(d),enc['attention_mask'][j:j+a.batch_size].to(d)).cpu())
v=torch.cat(ivec).numpy();t=torch.cat(tvec).numpy();pre=a.output_prefix;os.makedirs(os.path.dirname(pre),exist_ok=True);np.save(pre+'_image_embeddings.npy',v);np.save(pre+'_caption_embeddings.npy',t);np.save(pre+'_caption_image_ids.npy',np.asarray(ids));
if a.save_similarity: np.save(pre+'_similarity.npy',v@t.T)
print('saved',v.shape,t.shape)
