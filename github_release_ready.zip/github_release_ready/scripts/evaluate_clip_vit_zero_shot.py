import argparse,csv,json,os,time
import numpy as np
import torch
from PIL import Image
from transformers import CLIPModel,CLIPProcessor

p=argparse.ArgumentParser();p.add_argument('--data',required=True);p.add_argument('--output-dir',required=True);p.add_argument('--model-id',default='openai/clip-vit-base-patch32');p.add_argument('--batch-size',type=int,default=64);p.add_argument('--device',default='cuda:0');a=p.parse_args();out=a.output_dir;os.makedirs(out,exist_ok=True);d=torch.device(a.device if torch.cuda.is_available() else 'cpu')
meta=json.load(open(os.path.join(a.data,'test_metadata.json'),encoding='utf-8'));caps=[c for r in meta for c in r['captions']];ids=np.asarray([i for i,r in enumerate(meta) for _ in r['captions']])
model=CLIPModel.from_pretrained(a.model_id).to(d).eval();processor=CLIPProcessor.from_pretrained(a.model_id)
def sync():
 if d.type=='cuda':torch.cuda.synchronize(d)
images=[];image_ms=0.;text_ms=0.
with torch.inference_mode():
 for s in range(0,len(meta),a.batch_size):
  ims=[Image.open(os.path.join(a.data,'test',r['image_filename'])).convert('RGB') for r in meta[s:s+a.batch_size]];x=processor(images=ims,return_tensors='pt')['pixel_values'].to(d);sync();st=time.perf_counter();z=model.get_image_features(pixel_values=x);sync();image_ms+=(time.perf_counter()-st)*1000;images.append(z.cpu())
 texts=[]
 for s in range(0,len(caps),a.batch_size):
  x=processor(text=caps[s:s+a.batch_size],padding=True,truncation=True,return_tensors='pt');x={k:v.to(d) for k,v in x.items()};sync();st=time.perf_counter();z=model.get_text_features(**x);sync();text_ms+=(time.perf_counter()-st)*1000;texts.append(z.cpu())
v=torch.cat(images);t=torch.cat(texts);v=torch.nn.functional.normalize(v,dim=1);t=torch.nn.functional.normalize(t,dim=1);sync();st=time.perf_counter();sim=(v@t.T).numpy();sync();similarity_ms=(time.perf_counter()-st)*1000
ri=np.argsort(-sim,axis=1,kind='stable');rt=np.argsort(-sim.T,axis=1,kind='stable');ir=np.asarray([np.flatnonzero(ids[ri[i]]==i)[0] for i in range(len(v))]);tr=np.asarray([np.flatnonzero(rt[j]==ids[j])[0] for j in range(len(t))])
def rec(r,k):return float((r<k).mean()*100)
def block(r):return {f'R@{k}':rec(r,k) for k in (1,5,10)}|{'MRR':float((1/(r+1)).mean()*100),'mAP':float((1/(r+1)).mean()*100)}
result={'model':a.model_id,'image_to_text':block(ir),'text_to_image':block(tr),'candidate_pool':{'images':len(v),'captions':len(t),'scope':'dataset-level'},'latency':{'image_encoding_ms_total':image_ms,'text_encoding_ms_total':text_ms,'similarity_ms':similarity_ms,'total_ms':image_ms+text_ms+similarity_ms,'image_throughput_per_s':len(v)/(image_ms/1000),'peak_gpu_memory_mb':torch.cuda.max_memory_allocated(d)/1024**2 if d.type=='cuda' else None}}
np.save(os.path.join(out,'clip_image_embeddings.npy'),v.numpy());np.save(os.path.join(out,'clip_caption_embeddings.npy'),t.numpy());np.save(os.path.join(out,'clip_caption_image_ids.npy'),ids);np.save(os.path.join(out,'clip_similarity.npy'),sim);json.dump(result,open(os.path.join(out,'clip_baseline_metrics.json'),'w'),indent=2)
with open(os.path.join(out,'clip_baseline_results.csv'),'w',newline='') as f:w=csv.writer(f);w.writerow(['Method','Backbone','i2t R@1','i2t R@5','i2t R@10','t2i R@1','t2i R@5','t2i R@10','Candidate Pool']);w.writerow(['CLIP baseline',a.model_id,result['image_to_text']['R@1'],result['image_to_text']['R@5'],result['image_to_text']['R@10'],result['text_to_image']['R@1'],result['text_to_image']['R@5'],result['text_to_image']['R@10'],'1512 images x 3024 captions'])
open(os.path.join(out,'clip_baseline_results.md'),'w').write('# CLIP / ViT dataset-level baseline\n\n'+json.dumps(result,indent=2)+'\n')
with open(os.path.join(out,'clip_latency_results.csv'),'w',newline='') as f:w=csv.writer(f);w.writerow(['model','image_encoding_ms_total','text_encoding_ms_total','similarity_ms','total_ms','image_throughput_per_s','peak_gpu_memory_mb']);w.writerow([a.model_id,image_ms,text_ms,similarity_ms,result['latency']['total_ms'],result['latency']['image_throughput_per_s'],result['latency']['peak_gpu_memory_mb']])
open(os.path.join(out,'clip_latency_results.md'),'w').write('# CLIP latency\n\n'+json.dumps(result['latency'],indent=2)+'\n');print(json.dumps(result,indent=2))
