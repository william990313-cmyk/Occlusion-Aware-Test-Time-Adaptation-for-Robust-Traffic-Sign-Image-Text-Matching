"""Fine-tune a public CLIP checkpoint on the main traffic-sign train split only.

Selection is made by strict dataset-level validation image-to-text R@1.  The test
split is intentionally not read by this script.
"""
import argparse
import csv
import json
import os
import random

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from torch.utils.data import DataLoader, Dataset
from transformers import CLIPModel, CLIPProcessor


def load_metadata(data_dir, split):
    path = os.path.join(data_dir, f"{split}_metadata.json")
    with open(path, encoding="utf-8") as handle:
        return json.load(handle)


class OneCaptionPerImage(Dataset):
    """One independently sampled positive caption per image, avoiding false negatives."""

    def __init__(self, data_dir, records, split, seed):
        self.image_dir = os.path.join(data_dir, split)
        self.records = records
        self.seed = seed
        self.epoch = 0

    def set_epoch(self, epoch):
        self.epoch = epoch

    def __len__(self):
        return len(self.records)

    def __getitem__(self, index):
        record = self.records[index]
        # Deterministic, but selects one of the two valid captions differently by epoch.
        caption_index = random.Random(self.seed + self.epoch * 1000003 + index).randrange(
            len(record["captions"])
        )
        image = Image.open(os.path.join(self.image_dir, record["image_filename"])).convert("RGB")
        return image, record["captions"][caption_index]


def make_collate(processor):
    def collate(batch):
        images, texts = zip(*batch)
        image_inputs = processor(images=list(images), return_tensors="pt")
        text_inputs = processor(text=list(texts), padding=True, truncation=True, return_tensors="pt")
        return image_inputs["pixel_values"], text_inputs["input_ids"], text_inputs["attention_mask"]

    return collate


@torch.inference_mode()
def dataset_metrics(model, processor, data_dir, split, batch_size, device):
    """Correct multi-positive, dataset-level Recall@K for validation only."""
    records = load_metadata(data_dir, split)
    image_dir = os.path.join(data_dir, split)
    captions = [caption for record in records for caption in record["captions"]]
    caption_image_ids = np.asarray(
        [image_id for image_id, record in enumerate(records) for _ in record["captions"]]
    )
    image_parts = []
    text_parts = []
    model.eval()
    for start in range(0, len(records), batch_size):
        images = [
            Image.open(os.path.join(image_dir, record["image_filename"])).convert("RGB")
            for record in records[start : start + batch_size]
        ]
        pixel_values = processor(images=images, return_tensors="pt")["pixel_values"].to(device)
        image_parts.append(model.get_image_features(pixel_values=pixel_values).cpu())
    for start in range(0, len(captions), batch_size):
        inputs = processor(
            text=captions[start : start + batch_size], padding=True, truncation=True, return_tensors="pt"
        )
        inputs = {key: value.to(device) for key, value in inputs.items()}
        text_parts.append(model.get_text_features(**inputs).cpu())
    image_embeddings = F.normalize(torch.cat(image_parts), dim=1).numpy()
    text_embeddings = F.normalize(torch.cat(text_parts), dim=1).numpy()
    similarity = image_embeddings @ text_embeddings.T
    i2t_order = np.argsort(-similarity, axis=1, kind="stable")
    t2i_order = np.argsort(-similarity.T, axis=1, kind="stable")
    i2t_ranks = np.asarray(
        [np.flatnonzero(caption_image_ids[i2t_order[index]] == index)[0] for index in range(len(records))]
    )
    t2i_ranks = np.asarray(
        [np.flatnonzero(t2i_order[index] == caption_image_ids[index])[0] for index in range(len(captions))]
    )

    def recalls(ranks):
        return {f"R@{k}": float((ranks < k).mean() * 100) for k in (1, 5, 10)}

    return {
        "image_to_text": recalls(i2t_ranks),
        "text_to_image": recalls(t2i_ranks),
        "candidate_pool": {"images": len(records), "captions": len(captions), "scope": "dataset-level"},
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--model-id", default="openai/clip-vit-base-patch32")
    parser.add_argument("--epochs", type=int, default=8)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--grad-accum", type=int, default=2)
    parser.add_argument("--lr", type=float, default=5e-6)
    parser.add_argument("--weight-decay", type=float, default=0.01)
    parser.add_argument("--num-workers", type=int, default=4)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", default="cuda:0")
    args = parser.parse_args()
    if args.epochs < 1 or args.batch_size < 2 or args.grad_accum < 1:
        raise ValueError("epochs >= 1, batch-size >= 2, and grad-accum >= 1 are required")

    os.makedirs(args.output_dir, exist_ok=True)
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if device.type == "cuda":
        torch.cuda.manual_seed_all(args.seed)

    processor = CLIPProcessor.from_pretrained(args.model_id)
    model = CLIPModel.from_pretrained(args.model_id).to(device)
    train_records = load_metadata(args.data, "train")
    train_dataset = OneCaptionPerImage(args.data, train_records, "train", args.seed)
    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        pin_memory=device.type == "cuda",
        collate_fn=make_collate(processor),
        persistent_workers=args.num_workers > 0,
    )
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    scaler = torch.cuda.amp.GradScaler(enabled=device.type == "cuda")
    log_path = os.path.join(args.output_dir, "clip_finetune_log.csv")
    best_path = os.path.join(args.output_dir, "clip_finetuned_best.pth.tar")
    best_r1 = float("-inf")

    with open(log_path, "w", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=["epoch", "train_contrastive_loss", "val_i2t_R@1", "val_i2t_R@5", "val_i2t_R@10", "val_t2i_R@1"],
        )
        writer.writeheader()
        for epoch in range(1, args.epochs + 1):
            train_dataset.set_epoch(epoch)
            model.train()
            optimizer.zero_grad(set_to_none=True)
            total_loss = 0.0
            batches = 0
            for step, (pixel_values, input_ids, attention_mask) in enumerate(train_loader, start=1):
                pixel_values = pixel_values.to(device, non_blocking=True)
                input_ids = input_ids.to(device, non_blocking=True)
                attention_mask = attention_mask.to(device, non_blocking=True)
                with torch.cuda.amp.autocast(enabled=device.type == "cuda"):
                    out = model(pixel_values=pixel_values, input_ids=input_ids, attention_mask=attention_mask)
                    labels = torch.arange(pixel_values.shape[0], device=device)
                    loss = 0.5 * (
                        F.cross_entropy(out.logits_per_image, labels)
                        + F.cross_entropy(out.logits_per_text, labels)
                    )
                    scaled_loss = loss / args.grad_accum
                scaler.scale(scaled_loss).backward()
                if step % args.grad_accum == 0 or step == len(train_loader):
                    scaler.unscale_(optimizer)
                    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                    scaler.step(optimizer)
                    scaler.update()
                    optimizer.zero_grad(set_to_none=True)
                total_loss += float(loss.detach())
                batches += 1

            metrics = dataset_metrics(model, processor, args.data, "val", args.batch_size, device)
            row = {
                "epoch": epoch,
                "train_contrastive_loss": total_loss / max(batches, 1),
                "val_i2t_R@1": metrics["image_to_text"]["R@1"],
                "val_i2t_R@5": metrics["image_to_text"]["R@5"],
                "val_i2t_R@10": metrics["image_to_text"]["R@10"],
                "val_t2i_R@1": metrics["text_to_image"]["R@1"],
            }
            writer.writerow(row)
            handle.flush()
            print(json.dumps(row))
            if row["val_i2t_R@1"] > best_r1:
                best_r1 = row["val_i2t_R@1"]
                torch.save(
                    {
                        "state_dict": model.state_dict(),
                        "model_id": args.model_id,
                        "epoch": epoch,
                        "best_val_i2t_R@1": best_r1,
                        "args": vars(args),
                    },
                    best_path,
                )

    summary = {
        "checkpoint": best_path,
        "selection_metric": "validation dataset-level image-to-text R@1",
        "best_val_i2t_R@1": best_r1,
        "train_images": len(train_records),
        "validation_images": len(load_metadata(args.data, "val")),
        "test_accessed": False,
        "protocol": "one sampled valid caption per training image; symmetric CLIP contrastive loss",
    }
    with open(os.path.join(args.output_dir, "clip_finetune_summary.json"), "w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
