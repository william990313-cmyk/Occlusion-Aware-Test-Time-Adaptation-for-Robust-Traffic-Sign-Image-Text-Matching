"""Evaluate a fine-tuned CLIP checkpoint with corrected multi-positive retrieval."""
import argparse
import csv
import json
import os
import time

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from transformers import CLIPModel, CLIPProcessor


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", required=True)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--split", choices=("val", "test"), default="test")
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--device", default="cuda:0")
    args = parser.parse_args()
    os.makedirs(args.output_dir, exist_ok=True)
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    checkpoint = torch.load(args.checkpoint, map_location="cpu")
    model_id = checkpoint["model_id"]
    model = CLIPModel.from_pretrained(model_id)
    model.load_state_dict(checkpoint["state_dict"], strict=True)
    model.to(device).eval()
    processor = CLIPProcessor.from_pretrained(model_id)
    with open(os.path.join(args.data, f"{args.split}_metadata.json"), encoding="utf-8") as handle:
        records = json.load(handle)
    image_dir = os.path.join(args.data, args.split)
    captions = [caption for record in records for caption in record["captions"]]
    caption_image_ids = np.asarray([i for i, record in enumerate(records) for _ in record["captions"]])
    image_parts, text_parts = [], []
    torch.cuda.reset_peak_memory_stats(device) if device.type == "cuda" else None
    image_ms = text_ms = 0.0
    with torch.inference_mode():
        for start in range(0, len(records), args.batch_size):
            images = [Image.open(os.path.join(image_dir, r["image_filename"])).convert("RGB") for r in records[start:start + args.batch_size]]
            pixels = processor(images=images, return_tensors="pt")["pixel_values"].to(device)
            if device.type == "cuda": torch.cuda.synchronize(device)
            tic = time.perf_counter(); image_parts.append(model.get_image_features(pixel_values=pixels).cpu())
            if device.type == "cuda": torch.cuda.synchronize(device)
            image_ms += (time.perf_counter() - tic) * 1000
        for start in range(0, len(captions), args.batch_size):
            inputs = processor(text=captions[start:start + args.batch_size], padding=True, truncation=True, return_tensors="pt")
            inputs = {key: value.to(device) for key, value in inputs.items()}
            if device.type == "cuda": torch.cuda.synchronize(device)
            tic = time.perf_counter(); text_parts.append(model.get_text_features(**inputs).cpu())
            if device.type == "cuda": torch.cuda.synchronize(device)
            text_ms += (time.perf_counter() - tic) * 1000
    images = F.normalize(torch.cat(image_parts), dim=1).numpy()
    texts = F.normalize(torch.cat(text_parts), dim=1).numpy()
    tic = time.perf_counter(); similarity = images @ texts.T; similarity_ms = (time.perf_counter() - tic) * 1000
    i2t_order = np.argsort(-similarity, axis=1, kind="stable")
    t2i_order = np.argsort(-similarity.T, axis=1, kind="stable")
    i2t_ranks = np.asarray([np.flatnonzero(caption_image_ids[i2t_order[i]] == i)[0] for i in range(len(records))])
    t2i_ranks = np.asarray([np.flatnonzero(t2i_order[i] == caption_image_ids[i])[0] for i in range(len(captions))])
    def recall(ranks, k): return float((ranks < k).mean() * 100)
    result = {
        "model": model_id,
        "checkpoint": os.path.abspath(args.checkpoint),
        "split": args.split,
        "image_to_text": {f"R@{k}": recall(i2t_ranks, k) for k in (1, 5, 10)},
        "text_to_image": {f"R@{k}": recall(t2i_ranks, k) for k in (1, 5, 10)},
        "candidate_pool": {"images": len(records), "captions": len(captions), "scope": "dataset-level"},
        "latency": {"image_encoding_ms_total": image_ms, "text_encoding_ms_total": text_ms, "similarity_ms": similarity_ms, "total_ms": image_ms + text_ms + similarity_ms, "peak_gpu_memory_mb": torch.cuda.max_memory_allocated(device) / 1024**2 if device.type == "cuda" else None},
    }
    prefix = f"clip_finetuned_{args.split}"
    np.save(os.path.join(args.output_dir, f"{prefix}_image_embeddings.npy"), images)
    np.save(os.path.join(args.output_dir, f"{prefix}_caption_embeddings.npy"), texts)
    np.save(os.path.join(args.output_dir, f"{prefix}_caption_image_ids.npy"), caption_image_ids)
    np.save(os.path.join(args.output_dir, f"{prefix}_similarity.npy"), similarity)
    with open(os.path.join(args.output_dir, f"{prefix}_metrics.json"), "w", encoding="utf-8") as handle: json.dump(result, handle, indent=2)
    with open(os.path.join(args.output_dir, f"{prefix}_results.csv"), "w", newline="") as handle:
        writer = csv.writer(handle); writer.writerow(["method","split","i2t_R@1","i2t_R@5","i2t_R@10","t2i_R@1","t2i_R@5","t2i_R@10","pool"])
        writer.writerow(["CLIP ViT-B/32 fine-tuned", args.split, *result["image_to_text"].values(), *result["text_to_image"].values(), f"{len(records)} images x {len(captions)} captions"])
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
