import argparse, csv, json, sys, time
from pathlib import Path
import numpy as np
import torch

p=argparse.ArgumentParser()
p.add_argument('--reranker-dir',required=True); p.add_argument('--image-embeddings',required=True); p.add_argument('--text-embeddings',required=True); p.add_argument('--caption-image-ids',required=True); p.add_argument('--similarity',required=True); p.add_argument('--checkpoint',required=True); p.add_argument('--output-dir',required=True); p.add_argument('--ks',nargs='+',type=int,default=[1,3,5,10,20,50]); p.add_argument('--device',default='cuda:0')
a=p.parse_args(); sys.path.insert(0,a.reranker_dir)
from rerank_main_pair_mlp import PairMLP, rerank_i2t, rerank_t2i, metrics
out=Path(a.output_dir); out.mkdir(parents=True,exist_ok=True); dev=torch.device(a.device if torch.cuda.is_available() else 'cpu')
v=np.load(a.image_embeddings); t=np.load(a.text_embeddings); ids=np.load(a.caption_image_ids); sim=np.load(a.similarity)
ck=torch.load(a.checkpoint,map_location='cpu'); model=PairMLP(int(ck['embed_dim'])).to(dev); model.load_state_dict(ck['state_dict']); model.eval()
rows=[]
for k in a.ks:
    start=time.perf_counter(); i2t=rerank_i2t(sim,v,t,model,k,dev); t2i=rerank_t2i(sim,v,t,model,k,dev)
    if dev.type=='cuda': torch.cuda.synchronize(dev)
    elapsed=time.perf_counter()-start; m=metrics(i2t,t2i,ids,len(v)); ii=m['image_to_text']; tt=m['text_to_image']
    row={'k':k,'i2t_R@1':ii['R@1'],'i2t_R@5':ii['R@5'],'i2t_R@10':ii['R@10'],'t2i_R@1':tt['R@1'],'t2i_R@5':tt['R@5'],'t2i_R@10':tt['R@10'],'reranking_seconds':elapsed,'monotonic_i2t':ii['R@10']>=ii['R@5']>=ii['R@1'],'monotonic_t2i':tt['R@10']>=tt['R@5']>=tt['R@1']}; rows.append(row); print(json.dumps(row),flush=True)
with open(out/'topk_sensitivity_results.csv','w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
with open(out/'topk_sensitivity_results.md','w') as f:
 f.write('# Top-K sensitivity: OATA + lightweight image-text pair reranker\n\n| K | i2t R@1 | i2t R@5 | i2t R@10 | t2i R@1 | t2i R@5 | t2i R@10 | Reranking time (s) | Monotonic |\n|---:|---:|---:|---:|---:|---:|---:|---:|---|\n')
 for r in rows: f.write(f"| {r['k']} | {r['i2t_R@1']:.4f} | {r['i2t_R@5']:.4f} | {r['i2t_R@10']:.4f} | {r['t2i_R@1']:.4f} | {r['t2i_R@5']:.4f} | {r['t2i_R@10']:.4f} | {r['reranking_seconds']:.3f} | {r['monotonic_i2t'] and r['monotonic_t2i']} |\n")
json.dump({'candidate_pool':{'images':len(v),'captions':len(t),'scope':'dataset-level'},'ks':a.ks,'rows':rows},open(out/'raw_results.json','w'),indent=2)
