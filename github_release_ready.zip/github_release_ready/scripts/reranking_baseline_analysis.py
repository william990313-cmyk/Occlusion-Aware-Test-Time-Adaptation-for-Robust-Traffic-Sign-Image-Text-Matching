import argparse,csv,json,sys,time
from pathlib import Path
import numpy as np
import torch

p=argparse.ArgumentParser();p.add_argument('--reranker-dir',required=True);p.add_argument('--base-prefix',required=True);p.add_argument('--oata-prefix',required=True);p.add_argument('--checkpoint',required=True);p.add_argument('--output-dir',required=True);p.add_argument('--topk',type=int,default=5);p.add_argument('--device',default='cuda:0');a=p.parse_args();sys.path.insert(0,a.reranker_dir)
from rerank_main_pair_mlp import PairMLP,metrics
out=Path(a.output_dir);out.mkdir(parents=True,exist_ok=True);dev=torch.device(a.device if torch.cuda.is_available() else 'cpu')
ck=torch.load(a.checkpoint,map_location='cpu');model=PairMLP(int(ck['embed_dim'])).to(dev);model.load_state_dict(ck['state_dict']);model.eval()
def load(pre): return (np.load(pre+'_image_embeddings.npy'),np.load(pre+'_caption_embeddings.npy'),np.load(pre+'_caption_image_ids.npy'),np.load(pre+'_similarity.npy'))
bv,bt,ids,bs=load(a.base_prefix);ov,ot,oids,osim=load(a.oata_prefix);assert np.array_equal(ids,oids)
def scores(v,t):
  x=[]
  with torch.no_grad():
    for z in range(0,len(v),4096): x.append(model(torch.as_tensor(v[z:z+4096],dtype=torch.float32,device=dev),torch.as_tensor(t[z:z+4096],dtype=torch.float32,device=dev)).sigmoid().cpu().numpy())
  return np.concatenate(x)
def rerank(sim,v,t,mode,alpha=None):
  ri=np.argsort(-sim,axis=1,kind='stable');rt=np.argsort(-sim.T,axis=1,kind='stable');oi=ri.copy();ot=rt.copy();k=a.topk
  for i in range(len(v)):
    ix=ri[i,:k]; ps=scores(np.repeat(v[i:i+1],k,0),t[ix]); ss=ps if mode=='pair' else alpha*sim[i,ix]+(1-alpha)*ps;oi[i,:k]=ix[np.argsort(-ss,kind='stable')]
  for j in range(len(t)):
    ix=rt[j,:k];ps=scores(v[ix],np.repeat(t[j:j+1],k,0));ss=ps if mode=='pair' else alpha*sim[ix,j]+(1-alpha)*ps;ot[j,:k]=ix[np.argsort(-ss,kind='stable')]
  return oi,ot
def run(name,sim,v,t,mode=None,alpha=None,training='no'):
  if dev.type=='cuda':torch.cuda.synchronize(dev)
  st=time.perf_counter()
  if mode is None: i2t=np.argsort(-sim,axis=1,kind='stable');t2i=np.argsort(-sim.T,axis=1,kind='stable')
  else:i2t,t2i=rerank(sim,v,t,mode,alpha)
  if dev.type=='cuda':torch.cuda.synchronize(dev)
  r=metrics(i2t,t2i,ids,len(v));ii=r['image_to_text'];tt=r['text_to_image'];row={'method':name,'topk':a.topk,'i2t_R@1':ii['R@1'],'i2t_R@5':ii['R@5'],'i2t_R@10':ii['R@10'],'t2i_R@1':tt['R@1'],'t2i_R@5':tt['R@5'],'t2i_R@10':tt['R@10'],'reranking_seconds':time.perf_counter()-st,'extra_training_required':training,'monotonic':ii['R@10']>=ii['R@5']>=ii['R@1'] and tt['R@10']>=tt['R@5']>=tt['R@1']};rows.append(row);print(json.dumps(row),flush=True)
rows=[];run('no_reranking',bs,bv,bt);run('similarity_only_topk',bs,bv,bt)
for alpha in (.25,.5,.75):run(f'weighted_fusion_alpha_{alpha}',bs,bv,bt,'fusion',alpha)
run('pair_reranker',bs,bv,bt,'pair');run('oata_pair_reranker',osim,ov,ot,'pair')
cols=list(rows[0]);
with open(out/'reranking_baseline_results.csv','w',newline='') as f:w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(rows)
with open(out/'reranking_baseline_results.md','w') as f:
 f.write('# Simple re-ranking baseline comparison\n\n| Method | i2t R@1 | i2t R@5 | i2t R@10 | t2i R@1 | t2i R@5 | t2i R@10 | Time (s) | Extra training | Monotonic |\n|---|---:|---:|---:|---:|---:|---:|---:|---|---|\n')
 for r in rows:f.write(f"| {r['method']} | {r['i2t_R@1']:.4f} | {r['i2t_R@5']:.4f} | {r['i2t_R@10']:.4f} | {r['t2i_R@1']:.4f} | {r['t2i_R@5']:.4f} | {r['t2i_R@10']:.4f} | {r['reranking_seconds']:.3f} | {r['extra_training_required']} | {r['monotonic']} |\n")
json.dump({'candidate_pool':{'images':len(bv),'captions':len(bt),'scope':'dataset-level'},'topk':a.topk,'fusion_pair_score':'sigmoid(pair_MLP_logit)','rows':rows},open(out/'raw_results.json','w'),indent=2)
