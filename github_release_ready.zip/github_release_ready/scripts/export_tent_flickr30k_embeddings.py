#!/usr/bin/env python3
"""TENT-adapt a clean Flickr30k checkpoint on occluded images and export embeddings.

This follows the supplied TENT/OATA implementation: image BN affine parameters
are trainable, BN running statistics update in train mode, Adam is used for ten
full passes over the adaptation loader, and adaptation accumulates without a
per-batch reset. Text parameters and the fixed first-caption text embeddings
used by the entropy objective are never updated.
"""
import argparse
import json
import os
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from PIL import Image
from torch.utils.data import DataLoader, Dataset
from transformers import AutoTokenizer

from dataset import get_transforms
from model_architecture import create_model


class FlickrTentDataset(Dataset):
    def __init__(self, data_dir, metadata_path, image_model, text_model):
        self.data_dir = Path(data_dir)
        self.meta = json.loads(Path(metadata_path).read_text(encoding="utf-8"))
        self.transform = get_transforms(image_model, is_training=False)
        tok_name = {"distilbert": "distilbert-base-uncased", "roberta": "roberta-base", "bert": "bert-base-uncased"}[text_model]
        self.tokenizer = AutoTokenizer.from_pretrained(tok_name)

    def __len__(self):
        return len(self.meta)

    def __getitem__(self, idx):
        item = self.meta[idx]
        path = self.data_dir / os.path.basename(item["image_path"])
        image = self.transform(Image.open(path).convert("RGB"))
        caption = item["captions"][0]  # deterministic, matching the legacy TENT loader's one-caption objective
        enc = self.tokenizer(caption, max_length=128, padding="max_length", truncation=True, return_tensors="pt")
        return image, enc["input_ids"].squeeze(0), enc["attention_mask"].squeeze(0)


def configure_tent(model):
    """Freeze all parameters except image-encoder BatchNorm affine weights/biases."""
    for p in model.parameters():
        p.requires_grad_(False)
    params = []
    for module in model.image_encoder.modules():
        if isinstance(module, (nn.BatchNorm1d, nn.BatchNorm2d, nn.BatchNorm3d, nn.SyncBatchNorm)):
            if module.affine:
                module.weight.requires_grad_(True)
                module.bias.requires_grad_(True)
                params.extend([module.weight, module.bias])
    if not params:
        raise RuntimeError("No affine BatchNorm parameters found in image_encoder")
    return params


def entropy_loss(image_embeddings, text_embeddings):
    logits = image_embeddings @ text_embeddings.T
    probs = logits.softmax(dim=1)
    return -(probs * (probs.clamp_min(1e-12).log())).sum(dim=1).mean()


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--checkpoint", required=True)
    p.add_argument("--data-dir", required=True)
    p.add_argument("--metadata", required=True)
    p.add_argument("--output-dir", required=True)
    p.add_argument("--image-model", default="resnext50_32x4d")
    p.add_argument("--text-model", default="distilbert")
    p.add_argument("--embed-dim", type=int, default=512)
    p.add_argument("--batch-size", type=int, default=64)
    p.add_argument("--num-workers", type=int, default=4)
    p.add_argument("--tent-passes", type=int, default=10)
    p.add_argument("--lr", type=float, default=1e-5)
    p.add_argument("--device", default="cuda:0")
    args = p.parse_args()
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")

    ck = torch.load(args.checkpoint, map_location="cpu")
    saved = ck.get("args", {})
    image_model = saved.get("image_model", args.image_model)
    text_model = saved.get("text_model", args.text_model)
    model = create_model(embed_dim=saved.get("embed_dim", args.embed_dim), image_model_type=image_model, text_model_type=text_model).to(device)
    model.load_state_dict(ck["state_dict"])
    trainable = configure_tent(model)
    optimizer = torch.optim.Adam(trainable, lr=args.lr)
    ds = FlickrTentDataset(args.data_dir, args.metadata, image_model, text_model)
    loader = DataLoader(ds, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers, pin_memory=True)

    # Accumulating TENT: no reset between batches or passes. Text encoder is eval/frozen.
    model.train()
    model.text_encoder.eval()  # disable dropout; text weights and outputs remain fixed
    losses = []
    for pass_idx in range(args.tent_passes):
        total = 0.0
        count = 0
        for images, input_ids, attention_mask in loader:
            images = images.to(device, non_blocking=True)
            input_ids = input_ids.to(device, non_blocking=True)
            attention_mask = attention_mask.to(device, non_blocking=True)
            with torch.no_grad():
                text = model.get_text_embeddings(input_ids, attention_mask)
            image = model.get_image_embeddings(images)
            loss = entropy_loss(image, text)
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            optimizer.step()
            total += loss.item() * images.size(0)
            count += images.size(0)
        mean_loss = total / max(count, 1)
        losses.append(mean_loss)
        print(f"TENT pass {pass_idx + 1}/{args.tent_passes}: entropy={mean_loss:.6f}", flush=True)

    # Export adapted image embeddings in deterministic metadata order.
    model.eval()
    images_only = DataLoader(ImageOnly(ds), batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers, pin_memory=True)
    embeddings = []
    with torch.no_grad():
        for images in images_only:
            embeddings.append(model.get_image_embeddings(images.to(device, non_blocking=True)).cpu())
    image_embeddings = torch.cat(embeddings).numpy()
    np.save(out / "tent_occluded_image_embeddings.npy", image_embeddings)
    (out / "tent_occluded_metadata.json").write_text(json.dumps(ds.meta, ensure_ascii=False, indent=2), encoding="utf-8")
    protocol = vars(args).copy()
    protocol.update({"resolved_image_model": image_model, "resolved_text_model": text_model,
                     "device": str(device), "bn_parameter_policy": "image_encoder affine BN only",
                     "bn_running_stats": "updated cumulatively in train mode", "text_embeddings": "fixed per batch; text encoder frozen",
                     "reset_strategy": "no reset; adaptation accumulates across all batches and passes",
                     "entropy_losses": losses, "checkpoint_args": saved, "embedding_shape": list(image_embeddings.shape)})
    (out / "tent_protocol.json").write_text(json.dumps(protocol, ensure_ascii=False, indent=2), encoding="utf-8")
    print("saved", image_embeddings.shape, "to", out)


class ImageOnly(Dataset):
    def __init__(self, source):
        self.source = source

    def __len__(self):
        return len(self.source)

    def __getitem__(self, idx):
        return self.source[idx][0]


if __name__ == "__main__":
    main()
