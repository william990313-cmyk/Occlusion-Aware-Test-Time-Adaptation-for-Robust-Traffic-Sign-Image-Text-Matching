import argparse,csv,json,os,sys
from collections import defaultdict
from pathlib import Path
import numpy as np
import torch
import matplotlib.pyplot as plt
from PIL import Image

p=argparse.ArgumentParser();p.add_argument('--data',required=True);p.add_argument('--reranker-dir',required=True);p.add_argument('--base-prefix',required=True);p.add_argument('--oata-prefix',required=True);p.add_argument('--checkpoint',required=True);p.add_argument('--output-dir',required=True);p.add_argument('--topk',type=int,default=5);p.add_argument('--device',default='cuda:0');a=p.parse_args();sys.path.insert(0,a.reranker_dir)
from rerank_main_pair_mlp import PairMLP,rerank_i2t
out=Path(a.output_dir);panel_dir=out/'failure_case_panels';panel_dir.mkdir(parents=True,exist_ok=True);dev=torch.device(a.device if torch.cuda.is_available() else 'cpu')
def load(pre):return np.load(pre+'_image_embeddings.npy'),np.load(pre+'_caption_embeddings.npy'),np.load(pre+'_caption_image_ids.npy'),np.load(pre+'_similarity.npy')
bv,bt,ids,bs=load(a.base_prefix);ov,ot,oids,osim=load(a.oata_prefix);assert np.array_equal(ids,oids)
ck=torch.load(a.checkpoint,map_location='cpu');m=PairMLP(int(ck['embed_dim'])).to(dev);m.load_state_dict(ck['state_dict']);m.eval()
base_rank=np.argsort(-bs,axis=1,kind='stable');oata_rank=np.argsort(-osim,axis=1,kind='stable');pair_rank=rerank_i2t(bs,bv,bt,m,a.topk,dev);full_rank=rerank_i2t(osim,ov,ot,m,a.topk,dev)
meta=json.load(open(Path(a.data)/'test_metadata.json',encoding='utf-8'));caps=[c for r in meta for c in r['captions']];cap_cat=[r.get('category','unknown') for r in meta for _ in r['captions']]
def grank(rank,i):
 if rank.ndim==2: rank=rank[i]
 return int(np.flatnonzero(ids[rank]==i)[0])+1
def correct(rank,i):return grank(rank,i)==1
def top(rank,i,n=5):return [caps[int(x)] for x in rank[i,:n]]
def reason(types,i):
 if 'topk_limitation' in types:return 'A valid caption is absent from OATA initial Top-5; Top-5 reranking cannot recover it.'
 if 'baseline_wrong_oata_correct' in types:return 'OATA moves a valid caption to rank 1.'
 if 'baseline_wrong_full_correct' in types:return 'The OATA plus pair-reranker output moves a valid caption to rank 1.'
 if 'baseline_correct_oata_wrong' in types:return 'OATA changes a baseline-correct top prediction to an incorrect caption.'
 if 'baseline_correct_reranker_wrong' in types:return 'Top-5 pair reranking changes a baseline-correct top prediction to an incorrect caption.'
 if 'semantic_confusion' in types:return 'The incorrect top caption belongs to the same available category label as the query, indicating category-level semantic confusion.'
 return 'No valid caption is ranked first by OATA plus pair reranking.'
types=defaultdict(list)
for i in range(len(meta)):
 if not correct(base_rank,i) and correct(oata_rank,i):types[i].append('baseline_wrong_oata_correct')
 if not correct(base_rank,i) and correct(full_rank,i):types[i].append('baseline_wrong_full_correct')
 if correct(base_rank,i) and not correct(oata_rank,i):types[i].append('baseline_correct_oata_wrong')
 if correct(base_rank,i) and not correct(pair_rank,i):types[i].append('baseline_correct_reranker_wrong')
 if not correct(full_rank,i):types[i].append('oata_pair_reranker_still_wrong')
 if not correct(full_rank,i) and grank(oata_rank,i)>a.topk:types[i].append('topk_limitation')
 if not correct(full_rank,i) and cap_cat[int(full_rank[i,0])]==meta[i].get('category','unknown'):types[i].append('semantic_confusion')
rows=[]
for i,ts in types.items():
 r=meta[i];rows.append({'sample_id':i,'image_path':str(Path(a.data)/'test'/r['image_filename']),'occlusion_type':r.get('occlusion_type','unknown'),'severity_level':r.get('severity_level','unknown'),'ground_truth_caption':' || '.join(r['captions']),'baseline_top1_caption':caps[int(base_rank[i,0])],'baseline_ground_truth_rank':grank(base_rank,i),'OATA_top1_caption':caps[int(oata_rank[i,0])],'OATA_ground_truth_rank':grank(oata_rank,i),'reranker_top1_caption':caps[int(pair_rank[i,0])],'reranker_ground_truth_rank':grank(pair_rank,i),'OATA_plus_reranker_top1_caption':caps[int(full_rank[i,0])],'OATA_plus_reranker_ground_truth_rank':grank(full_rank,i),'top5_baseline_candidates':json.dumps(top(base_rank,i)),'top5_OATA_candidates':json.dumps(top(oata_rank,i)),'top5_reranked_candidates':json.dumps(top(full_rank,i)),'failure_type':';'.join(ts),'short_reason':reason(ts,i)})
cols=list(rows[0]) if rows else ['sample_id'];
with open(out/'failure_cases_all.csv','w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(rows)
by=defaultdict(list)
for r in rows:
 for t in r['failure_type'].split(';'):by[t].append(r)
order=['baseline_wrong_oata_correct','baseline_wrong_full_correct','baseline_correct_oata_wrong','baseline_correct_reranker_wrong','oata_pair_reranker_still_wrong','topk_limitation','semantic_confusion']
selected=[];seen=set();limits={'baseline_wrong_oata_correct':5,'baseline_wrong_full_correct':5,'baseline_correct_oata_wrong':5,'baseline_correct_reranker_wrong':5,'oata_pair_reranker_still_wrong':10,'topk_limitation':5,'semantic_confusion':5}
for t in order:
 for r in by[t][:limits[t]]:
  if r['sample_id'] not in seen: selected.append(r);seen.add(r['sample_id'])
with open(out/'failure_cases_selected_for_paper.csv','w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(selected)
for n,r in enumerate(selected,1):
 i=int(r['sample_id']);im=Image.open(r['image_path']).convert('RGB');fig=plt.figure(figsize=(16,8));ax=fig.add_axes([.02,.25,.3,.7]);ax.imshow(im);ax.axis('off');fig.text(.35,.9,f"Case {n} | sample {i} | {r['failure_type']}",fontsize=13,weight='bold');txt=f"Ground truth:\n{r['ground_truth_caption']}\n\nBaseline top-1 (rank {r['baseline_ground_truth_rank']}):\n{r['baseline_top1_caption']}\n\nOATA top-1 (rank {r['OATA_ground_truth_rank']}):\n{r['OATA_top1_caption']}\n\nPair reranker top-1 (rank {r['reranker_ground_truth_rank']}):\n{r['reranker_top1_caption']}\n\nOATA + pair top-1 (rank {r['OATA_plus_reranker_ground_truth_rank']}):\n{r['OATA_plus_reranker_top1_caption']}\n\nReason: {r['short_reason']}";fig.text(.35,.82,txt,va='top',fontsize=8,wrap=True);fig.savefig(panel_dir/f'case_{n:02d}_sample_{i}.png',dpi=150,bbox_inches='tight');plt.close(fig)
counts={t:len(by[t]) for t in order};summary='# Failure-case summary\n\n'+ '\n'.join([f'- {t}: {counts[t]} cases.' for t in order])+f"\n- severe_occlusion_failure: 0 categorized cases; metadata has no severity field, so no severity was inferred.\n- selected panels: {len(selected)}.\n\nOATA and reranking case conclusions are based only on the exported ranks and available category metadata.\n"
(out/'failure_case_summary.md').write_text(summary,encoding='utf-8')
(out/'paper_ready_failure_case_caption.md').write_text('Representative cases on the main traffic-sign test set. OATA can promote a valid description under occlusion-induced shift, while the lightweight pair reranker can further correct candidates already present in the Top-5 prefix. Failure examples show that the framework can still select a semantically close description when key visual evidence is unavailable; Top-5 reranking cannot recover a valid caption that is absent from the initial candidate prefix.',encoding='utf-8')
(out/'failure_case_discussion_paragraph.md').write_text('The representative cases indicate that OATA can improve selected difficult queries by adapting the image backbone to occlusion-induced distribution shift, and the pair reranker can correct some cases when a valid description is already present in the initial Top-5 candidates. However, the combined framework still fails for visually ambiguous or semantically close candidate descriptions. When a key sign region is occluded, the appropriate description may be poorly ranked; in particular, a Top-5 reranker cannot recover a valid caption that is absent from the initial Top-5 prefix.',encoding='utf-8')
json.dump({'counts':counts,'selected_panels':len(selected),'candidate_pool':{'images':len(bv),'captions':len(bt),'scope':'dataset-level'}},open(out/'raw_summary.json','w'),indent=2);print(json.dumps({'counts':counts,'selected_panels':len(selected)},indent=2))
