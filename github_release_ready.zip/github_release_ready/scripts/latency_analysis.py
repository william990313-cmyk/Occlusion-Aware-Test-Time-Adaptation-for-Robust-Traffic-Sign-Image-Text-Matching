import argparse, csv, json, os, time
import torch
from model_architecture import create_model
from dataset import create_dataloaders

def sync(device):
    if device.type == 'cuda': torch.cuda.synchronize(device)

p=argparse.ArgumentParser(); p.add_argument('--data', required=True); p.add_argument('--checkpoint', required=True); p.add_argument('--output', required=True); p.add_argument('--batch-size', type=int, default=64); p.add_argument('--warmup', type=int, default=5); p.add_argument('--device', default='cuda:0')
a=p.parse_args(); device=torch.device(a.device if torch.cuda.is_available() else 'cpu')
obj=torch.load(a.checkpoint,map_location='cpu'); cfg=obj.get('args',{})
model=create_model(embed_dim=cfg.get('embed_dim',512),image_model_type=cfg.get('image_model','resnext50_32x4d'),text_model_type=cfg.get('text_model','distilbert')); model.load_state_dict(obj['state_dict']); model.to(device).eval()
_,_,loader=create_dataloaders(processed_data_path=a.data,text_model_type=cfg.get('text_model','distilbert'),image_model_type=cfg.get('image_model','resnext50_32x4d'),batch_size=a.batch_size,num_workers=0)
times=[]; n=0
with torch.inference_mode():
  for i,b in enumerate(loader):
    images=b['image'].to(device); ids=b['input_ids'].to(device); mask=b['attention_mask'].to(device); sync(device); t=time.perf_counter(); model(images,ids,mask); sync(device); dt=(time.perf_counter()-t)*1000
    if i>=a.warmup: times.append(dt); n += images.shape[0]
vals=sorted(times); med=vals[len(vals)//2]; p95=vals[min(len(vals)-1,int(.95*len(vals))-1)]
os.makedirs(os.path.dirname(a.output),exist_ok=True); result={'method':'baseline','split':'test','batches_timed':len(times),'images_timed':n,'batch_size':a.batch_size,'device':str(device),'median_batch_ms':med,'p95_batch_ms':p95,'images_per_s':(a.batch_size/(med/1000))}; json.dump(result,open(a.output+'.json','w'),indent=2); print(json.dumps(result,indent=2))
