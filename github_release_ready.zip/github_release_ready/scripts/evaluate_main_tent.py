import argparse, os, json, torch
import torch.nn as nn
import torch.nn.functional as F
from model_architecture import create_model
from dataset import create_dataloaders

def configure(model):
    for p in model.parameters(): p.requires_grad_(False)
    params=[]
    for m in model.modules():
        if isinstance(m, nn.modules.batchnorm._BatchNorm):
            m.train(); m.weight.requires_grad_(True); m.bias.requires_grad_(True)
            params += [m.weight, m.bias]
    return params

def entropy_loss(img, txt):
    logits = img @ txt.detach().T
    p = F.softmax(logits, dim=1)
    return -(p * (p.clamp_min(1e-8).log())).sum(1).mean()

p=argparse.ArgumentParser(); p.add_argument('--data',required=True); p.add_argument('--checkpoint',required=True); p.add_argument('--output',required=True); p.add_argument('--batch-size',type=int,default=64); p.add_argument('--steps',type=int,default=20); p.add_argument('--lr',type=float,default=1e-5); p.add_argument('--device',default='cuda:0'); a=p.parse_args()
d=torch.device(a.device if torch.cuda.is_available() else 'cpu'); o=torch.load(a.checkpoint,map_location='cpu'); c=o.get('args',{})
m=create_model(embed_dim=c.get('embed_dim',512), image_model_type=c.get('image_model','resnext50_32x4d'), text_model_type=c.get('text_model','distilbert')); m.load_state_dict(o['state_dict']); m.to(d)
params=configure(m); opt=torch.optim.Adam(params,lr=a.lr)
_,_,dl=create_dataloaders(processed_data_path=a.data,text_model_type=c.get('text_model','distilbert'),image_model_type=c.get('image_model','resnext50_32x4d'),batch_size=a.batch_size,num_workers=0)
records=[]; m.train()
for b in dl:
    x=b['image'].to(d); ids=b['input_ids'].to(d); mask=b['attention_mask'].to(d)
    with torch.no_grad(): txt=m.get_text_embeddings(ids,mask)
    for _ in range(a.steps):
        opt.zero_grad(); img=m.get_image_embeddings(x); loss=entropy_loss(img,txt); loss.backward(); opt.step()
    with torch.no_grad(): img=m.get_image_embeddings(x); records.append({'image':img.cpu(),'text':txt.cpu()})
os.makedirs(a.output,exist_ok=True); torch.save({'image_embeddings':torch.cat([r['image'] for r in records]),'text_embeddings':torch.cat([r['text'] for r in records])},os.path.join(a.output,'pure_tent_embeddings.pt'))
json.dump({'method':'pure_tent','bn_layers':sum(isinstance(x,nn.modules.batchnorm._BatchNorm) for x in m.modules()),'steps':a.steps,'lr':a.lr,'optimizer':'Adam','extra_losses':False,'text_encoder':'frozen'},open(os.path.join(a.output,'protocol.json'),'w'),indent=2)
print('saved:',a.output)
