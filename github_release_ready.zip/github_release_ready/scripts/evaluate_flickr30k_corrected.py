#!/usr/bin/env python3
"""Dataset-level Flickr30k retrieval metrics from a saved similarity matrix.

Rows are query images and columns are candidate captions. ``caption_image_ids``
maps each caption column to its source image row. This supports Flickr30k's
standard five-positive-captions-per-image protocol without assuming a square
one-caption-per-image matrix.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Iterable

import numpy as np


def _recalls_from_ranks(ranks: np.ndarray, ks: Iterable[int]) -> dict[str, float]:
    if ranks.ndim != 1 or ranks.size == 0:
        raise ValueError("ranks must be a non-empty 1-D array")
    result = {f"R@{k}": float(np.mean(ranks < k) * 100.0) for k in ks}
    values = list(result.values())
    if values != sorted(values):
        raise AssertionError("Recall must be non-decreasing with K")
    return result


def image_to_text_ranks(similarity: np.ndarray, caption_image_ids: np.ndarray) -> np.ndarray:
    """Return the zero-based rank of the best valid caption for every image."""
    similarity = np.asarray(similarity)
    caption_image_ids = np.asarray(caption_image_ids)
    if similarity.ndim != 2:
        raise ValueError("similarity must have shape [num_images, num_captions]")
    if similarity.shape[1] != caption_image_ids.size:
        raise ValueError("caption_image_ids length must equal similarity columns")
    if not np.isfinite(similarity).all():
        raise ValueError("similarity contains NaN or infinity")
    ranks = np.empty(similarity.shape[0], dtype=np.int64)
    for image_id in range(similarity.shape[0]):
        positives = caption_image_ids == image_id
        if not positives.any():
            raise ValueError(f"image {image_id} has no positive caption")
        order = np.argsort(-similarity[image_id], kind="stable")
        ranks[image_id] = int(np.flatnonzero(positives[order])[0])
    return ranks


def text_to_image_ranks(similarity: np.ndarray, caption_image_ids: np.ndarray) -> np.ndarray:
    """Return the zero-based rank of the source image for every caption query."""
    similarity = np.asarray(similarity)
    caption_image_ids = np.asarray(caption_image_ids)
    if similarity.ndim != 2 or similarity.shape[1] != caption_image_ids.size:
        raise ValueError("expected [num_images, num_captions] and one id per caption")
    if np.any(caption_image_ids < 0) or np.any(caption_image_ids >= similarity.shape[0]):
        raise ValueError("caption_image_ids contains an invalid image index")
    order = np.argsort(-similarity.T, axis=1, kind="stable")
    return np.array(
        [np.flatnonzero(order[j] == caption_image_ids[j])[0] for j in range(order.shape[0])],
        dtype=np.int64,
    )


def compute_retrieval_metrics(
    similarity: np.ndarray,
    caption_image_ids: np.ndarray,
    ks: tuple[int, ...] = (1, 5, 10),
) -> dict[str, dict[str, float]]:
    """Compute dataset-level image-to-text and text-to-image Recall@K."""
    if not ks or any(k <= 0 for k in ks) or tuple(sorted(set(ks))) != ks:
        raise ValueError("ks must be unique positive integers in increasing order")
    return {
        "image_to_text": _recalls_from_ranks(image_to_text_ranks(similarity, caption_image_ids), ks),
        "text_to_image": _recalls_from_ranks(text_to_image_ranks(similarity, caption_image_ids), ks),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--similarity", type=Path, required=True, help=".npy [images, captions]")
    parser.add_argument("--caption-image-ids", type=Path, required=True, help=".npy integer vector")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = compute_retrieval_metrics(np.load(args.similarity), np.load(args.caption_image_ids))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
