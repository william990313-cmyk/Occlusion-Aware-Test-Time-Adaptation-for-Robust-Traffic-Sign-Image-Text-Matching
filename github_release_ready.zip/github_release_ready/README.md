# Occlusion-Aware Test-Time Adaptation for Robust Traffic-Sign Image-Text Matching

This release package accompanies the revised manuscript.  It contains the code needed to reproduce the corrected evaluation protocol and the public, compact result tables.  It deliberately excludes datasets, trained checkpoints, raw prediction files, and image panels because they are large and/or contain local file locations.

## What is included

- `src/`: dual-encoder model, data loader, training entry point, and utilities.
- `scripts/`: corrected dataset-level retrieval, BN-TENT, full OATA reference, lightweight image-text pair reranking, latency, Top-K, failure-case, and CLIP/ViT supplementary scripts.
- `revision_results_public/`: manuscript-ready tables and public audit summaries for Tasks 1 and 3--9.
- `docs/`: evaluation protocol and reproducibility notes.

## Important evaluation correction

All reported corrected retrieval values use a dataset-level candidate pool.  In the main traffic-sign test set this is **1,512 images x 3,024 captions**; in Flickr30k validation/test it is **2,214 images x 11,070 captions**.  A prediction is correct when any valid caption associated with the query image is retrieved.  Therefore R@10 >= R@5 >= R@1 by construction.

The identical Flickr30k Table-7 values in the original version are not retained as a valid retrieval result.  See `revision_results_public/paper_ready/table_flickr30k_corrected.md` and `docs/flickr30k_metric_correction.md`.

## Environment

The experiments were run with Python 3.10, PyTorch 2.1.2+cu118, CUDA 11.8, and an NVIDIA GeForce RTX 3080 Ti.  Install compatible versions of `torch`, `torchvision`, `transformers`, `timm`, `numpy`, `Pillow`, `tqdm`, and `matplotlib`.

## Reproduction outline

Set paths to your local copy of the data and a checkpoint.  The original data and checkpoints are not redistributed in this repository.

```bash
export PYTHONPATH="$PWD/src"
python scripts/evaluate_flickr30k_corrected.py --help
python scripts/evaluate_main_reranker.py --help
python scripts/topk_sensitivity.py --help
```

The OATA reference uses environment variables so no local absolute path is embedded:

```bash
export OATA_CHECKPOINT=/path/to/model_best.pth.tar
export OATA_DATASET_PATH=/path/to/test
export OATA_METADATA_PATH=/path/to/test_metadata.json
export OATA_OUTPUT_DIR=./oata_results
PYTHONPATH="$PWD/src" python scripts/evaluate_main_oata_reference.py
```

## Scope and limitations

The traffic-sign test set has 190 categories and two captions per image.  The occlusions are synthetic.  Full OATA runs 20 adaptation steps across the full test stream; it is not a real-time per-frame claim.  The lightweight pair reranker only reorders the initial Top-K candidates and cannot recover a correct caption absent from that candidate set.  CLIP ViT-B/32 is LayerNorm-based (not BatchNorm-based), so direct BN-TENT is not applicable.

## License and data

Please add the license that governs your project before making this repository public.  Dataset access and redistribution should follow the relevant source datasets' licenses.
