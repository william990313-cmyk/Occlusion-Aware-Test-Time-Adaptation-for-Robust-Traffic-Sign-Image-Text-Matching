# Failure-case summary

- baseline_wrong_oata_correct: 12 cases.
- baseline_wrong_full_correct: 18 cases.
- baseline_correct_oata_wrong: 11 cases.
- baseline_correct_reranker_wrong: 9 cases.
- oata_pair_reranker_still_wrong: 50 cases.
- topk_limitation: 2 cases.
- semantic_confusion: 0 cases.
- severe_occlusion_failure: 0 categorized cases; metadata has no severity field, so no severity was inferred.
- selected panels: 27.

OATA and reranking case conclusions are based only on the exported ranks and available category metadata.
