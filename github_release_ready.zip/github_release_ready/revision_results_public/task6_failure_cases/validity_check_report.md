# Validity checks

- Candidate pool: complete dataset-level pool of 1,512 images × 3,024 captions.
- Ranking inputs: actual baseline and OATA similarity matrices plus the existing trained lightweight image-text pair MLP.
- Invalid historical method: the old text-text `ms-marco` script was not used.
- Multiple valid captions: an i2t prediction is correct when either caption associated with the query image is ranked first; reported ground-truth rank is the best rank among both valid captions.
- Image identity: every panel is loaded from the `test_metadata.json` `image_filename` matched under the processed test directory.
- Training: none was run in Task 6.
- Occlusion metadata: no explicit occlusion type or severity field is available in the test metadata; such fields are exported as `unknown`, and no severity-based explanation is inferred.
- Case provenance: every exported case is derived from the saved rank arrays recomputed from actual embeddings; the corrected counts are consistent with the measured i2t R@1 values.
