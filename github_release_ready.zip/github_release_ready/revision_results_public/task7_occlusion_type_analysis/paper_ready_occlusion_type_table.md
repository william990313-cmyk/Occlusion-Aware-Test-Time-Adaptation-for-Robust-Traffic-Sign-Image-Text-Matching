# Historical synthetic occlusion stress-test table (appendix only)

| Strong synthetic occlusion | Baseline R@1 | TENT R@1 | Historical gain |
|---|---:|---:|---:|
| Fire | 7.94 | 16.63 | 8.70 |
| Light glare | 48.02 | 77.91 | 29.89 |
| Rain | 5.89 | 54.23 | 48.35 |
| Fog | 69.41 | 91.40 | 21.99 |
| Snow | 26.12 | 54.66 | 28.54 |
| Tree branch | 16.34 | 38.53 | 22.19 |

Historical manuscript values only. The original protocol lacks the directional, pool-size, and R@10 information required for comparison with the corrected dataset-level experiments; do not present this as a revised main-table result.
