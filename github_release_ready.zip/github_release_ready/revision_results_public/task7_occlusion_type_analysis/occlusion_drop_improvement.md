# Historical performance drops and TENT gains

Using the historical clean baseline R@1=94.91 as the reference, the largest historical baseline drop is Rain-S (89.02 points), closely followed by Fire-S (86.97 points) and Tree-S (78.57 points). The strongest historical TENT R@1 gain is Rain-S (+48.35 points), followed by Rain-M (+44.31) and Snow-M (+39.55). No per-type OATA or reranker values were found, so their improvements cannot be computed from existing files.

These calculations are descriptive only because the underlying historical protocol has not been verified as the corrected dataset-level protocol.
