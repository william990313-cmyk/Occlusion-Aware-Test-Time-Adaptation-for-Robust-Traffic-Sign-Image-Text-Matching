# Validity check report

- Source paths recorded: `main/main.tex` tables `tab:tent_occlusion`, `tab:mask`, `tab:module`, and `tab:main`.
- Occlusion types recovered: fire, light glare, rain, fog, snow, and tree branch; each has L/M/S historical rows.
- Methods recovered per type: baseline and TENT only.
- Corrected dataset-level protocol: **not verified**. The historical table does not state the candidate-pool size, retrieval direction, R@10, or per-subset test size.
- Recall monotonicity: only historical R@1 and R@5 are available; R@5 is at least R@1 for all rows. R@10 cannot be checked because it is absent.
- Invalid results: no Flickr30k result and no historical text-text CE score is included in the Task 7 table.
- Main-table use: prohibited. The recovered values must not be mixed with Tasks 3–6 corrected dataset-level values.
- Status: partial audit only; corrected per-type re-evaluation remains outstanding.
