# Existing single-occlusion-type result audit

## Results found

- `main/main.tex`, Table `tab:tent_occlusion` (lines 253–284): clean-trained baseline and TENT results for clean plus Fire/Light/Rain/Fog/Snow/Tree at L/M/S severity.
- `main/main.tex`, Table `tab:mask` (lines 209–217): synthetic mask-ratio summary for the same six types and three severities.
- `main/main.tex`, Table `tab:module` and `tab:main`: aggregate OATA and other module results, but not per-occlusion-type OATA results.

## Protocol audit

The historical per-type table reports one-direction `R@1`, `R@5`, and `mAP`; it does not report `R@10`, image-to-text/text-to-image directions separately, candidate-pool size, or exact per-type test-set size. It therefore cannot be verified as the corrected 1,512-image × 3,024-caption dataset-level protocol and must not be merged with Tasks 3–6 results.

The current `data/data/test` directory also does not contain a full 1,512-image dataset for each type: it contains 1,344 clean filenames plus small mixed subsets with `fire`, `light`, `rain`, `snow`, `tree`, and `smoke` prefixes. Thus it is not evidence that the original single-type full-test sets remain available locally.

## Usability

The historical baseline/TENT table is usable only as an audited appendix-style, historical synthetic-stress-test record. It is **not usable** as a corrected dataset-level comparison in the revised main paper without rerunning each single-type full test under the corrected protocol. No per-type OATA, pair-reranker, OATA+pair-reranker, or retrained-model results were found.
