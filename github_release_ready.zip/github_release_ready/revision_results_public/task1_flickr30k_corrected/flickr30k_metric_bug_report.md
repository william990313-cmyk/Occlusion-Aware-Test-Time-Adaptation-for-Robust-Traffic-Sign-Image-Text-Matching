# Flickr30k Table 7 metric bug report

## Finding

**A bug and a protocol violation were found.** The identical OATA values are not supported as valid Recall@1/5/10 measurements. The evidence points to the CE re-ranking implementation, not merely a table-copy typo.

The metric lines themselves use three different slices (`:1`, `:5`, `:10`). However, the preceding re-ranker leaks the query's ground-truth caption: it compares that caption against every candidate caption. When the diagonal ground truth lies in the initial Top-64, self-text similarity tends to move it to rank 1. When it lies outside Top-64, it is not reranked and remains below rank 64. This collapses ranks into two groups and makes R@1, R@5 and R@10 identical by construction or near-construction. With 2,214 queries, 60.48% corresponds to approximately 1,339 successes, consistent with a Top-64 gate rather than three independent recall cutoffs.

Additional protocol errors:

1. four of the five Flickr30k captions are discarded;
2. the script evaluates the custom validation split while the manuscript does not identify the split;
3. CE re-ranking is text-to-text, not image-to-text cross-modal verification;
4. the code assumes a square one-positive diagonal problem;
5. TENT adapts with batch-local negatives, so results can depend on batch composition even though final ranking is dataset-level;
6. no original log/result file exists to prove which code produced Table 7.

The candidate pool was not limited to one, and final dual-encoder retrieval was not batch-level. `TOPK=64` limits only the flawed second-stage reranking prefix. The evaluation function does not literally return one scalar for all K; the flawed rank transformation makes the three scalars equal.

## Fix

`evaluate_retrieval.py` is a modular evaluation-only replacement. It accepts a saved full image-caption similarity matrix plus a caption-to-image mapping, supports all five positives, computes both directions independently, and asserts Recall monotonicity. It does not alter training or model code.

The old CE script was retained unchanged for forensic reproducibility. Its text-text reranker should not be used to generate manuscript results. A valid OATA rerun additionally requires a genuine image-text cross-encoder or another non-leaking cross-modal scoring function.

## Table 7 status

The OATA row in the original Table 7 is wrong and must be withdrawn pending rerun; even its R@1 is leakage-contaminated. The other four rows are monotonic but could not be independently reproduced because no saved similarities/logs and no loadable model implementation/config are present. They are therefore manuscript-recorded, not verified corrected results.

Resolution status: **partially resolved**. The cause and metric implementation are resolved and tested, and the newly supplied project tree provides `model_architecture.py`. Numerical reevaluation is still blocked by the absent runnable PyTorch/timm/transformers environment, the lack of a clearly identified Flickr30k/OATA checkpoint-config pair, external CE weights, and saved embeddings/similarities.
