# TENT embedding export protocol

This protocol uses the clean checkpoint trained with ResNeXt-50 32x4d, DistilBERT, embedding dimension 512, and applies adaptation only to occluded Flickr30k images in `processed_data_n/processed_data_n/test`.

- Checkpoint: `train_clean_resnext50_distilbert/distilbert_resnext50_32x4d_bs64/model_best.pth.tar`.
- Occluded images: `processed_data_n/processed_data_n/test`.
- Metadata/captions: clean test metadata, reused for matching filenames and the five valid captions per image.
- Trainable parameters: affine weight and bias of every BatchNorm1d/2d/3d/SyncBatchNorm module under `image_encoder`.
- Frozen: all text-encoder parameters, all non-BN image parameters, and the text encoder is kept in eval mode.
- Entropy loss: `-sum(p * log(p))`, where `p = softmax(image_embedding @ fixed_batch_text_embeddings.T)`.
- Optimizer: Adam.
- Learning rate: `1e-5`.
- Batch size: 64.
- Adaptation passes: 10 full passes over the occluded test loader, matching the existing TENT implementation's `TENT_STEPS=10`.
- Reset strategy: no reset per batch or pass; BN affine parameters and running statistics accumulate through the loader.
- Text embeddings: fixed for each deterministic first-caption batch; text weights are never updated.
- Final image embeddings: exported after adaptation in metadata order. Retrieval metrics are computed separately with the full dataset-level 5N-caption pool.

The script is evaluation/adaptation only and does not train a new model or update the checkpoint on disk.
