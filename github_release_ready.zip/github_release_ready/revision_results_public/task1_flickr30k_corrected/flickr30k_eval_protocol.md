# Flickr30k evaluation protocol audit

## What the current OATA script actually does

- Split: custom **validation** split (`val`), not test, with 2,214 image records.
- Query direction: similarity rows are images and columns are texts, so the matrix operation is image-to-text.
- Candidate pool: dataset-level square matrix of 2,214 images by 2,214 texts after all batches are concatenated. It is not batch-level during final ranking.
- Captions: only `captions[0]` is selected, so four of five valid captions per image are discarded. The candidate pool is 2,214 texts, not all 11,070 captions.
- Ground truth: diagonal index equality (`candidate_index == query_index`).
- TENT adaptation: entropy is minimized on each 64-pair batch. This adaptation objective is batch-local, although final dual-encoder ranking is dataset-level.
- Re-ranking: the initial top 64 candidates per image are scored using `(caption_of_query_image, candidate_caption)`. The query image itself is never passed to the cross-encoder.

## Correct protocol implemented by the new metric module

For the supplied custom split, evaluate 2,214 query images against all 11,070 captions for image-to-text retrieval. Each image has five valid positive captions. For text-to-image retrieval, evaluate all 11,070 caption queries against all 2,214 images, with the source image as the positive.

For each query, sort the complete dataset-level candidate pool by descending model similarity. Let `rank` be one-based:

- image-to-text rank = best rank among all five ground-truth captions;
- text-to-image rank = rank of the caption's source image;
- Recall@K = `100 * mean(rank <= K)` for K in 1, 5, and 10.

Thus `R@10 >= R@5 >= R@1` is enforced. Batch size may control embedding throughput but must not define the retrieval pool. Re-ranking may reorder a declared top-M prefix, but it must use a genuine image-text relevance model and Recall@K must still be computed independently from the final full ranking.

For comparison with conventional published Flickr30k numbers, a separate run on the canonical 1,000-image test split should also be reported. The supplied 2,214-image test split is custom and must be disclosed as such; the two protocols must not be mixed in one table.
