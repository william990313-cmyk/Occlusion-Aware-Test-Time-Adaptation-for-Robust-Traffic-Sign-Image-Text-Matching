# TENT evaluation notes

Status: completed in WSL with the clean checkpoint and occluded `processed_data_n` test images.

Results:

- TENT i2t: 35.1400 / 63.4598 / 73.7127.
- TENT t2i: 25.8356 / 52.3487 / 63.3785.

Compared with clean model -> occluded (i2t 34.2367 / 63.4598 / 73.6224; t2i 25.6188 / 52.1409 / 63.3695), TENT improves i2t R@1 by 0.9033 points and R@10 by 0.0903, leaves i2t R@5 unchanged, and improves t2i by 0.2168 / 0.2078 / 0.0090 points.

Compared with retrained on occlusion (i2t 34.9142 / 64.2276 / 74.7064; t2i 25.6369 / 52.1951 / 63.3333), TENT is higher at i2t R@1 by 0.2258 and at all t2i cutoffs, but lower at i2t R@5 by 0.7678 and R@10 by 0.9937.

The corrected TENT result is valid and monotonic, but it does not validate the original Table 7 OATA row; that row remains invalid because its CE reranker used leaked text-text self-matching and produced 60.48/60.48/60.48.
