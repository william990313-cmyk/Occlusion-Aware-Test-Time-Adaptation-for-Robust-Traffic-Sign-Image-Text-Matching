# TENT corrected Flickr30k results

| Method | Dataset | Direction | R@1 | R@5 | R@10 |
|---|---|---|---:|---:|---:|
| TENT | Occluded Flickr30k | image-to-text | 35.1400 | 63.4598 | 73.7127 |
| TENT | Occluded Flickr30k | text-to-image | 25.8356 | 52.3487 | 63.3785 |

The full dataset-level pool contains 2,214 images and 11,070 captions. Both directions satisfy `R@10 >= R@5 >= R@1`.
