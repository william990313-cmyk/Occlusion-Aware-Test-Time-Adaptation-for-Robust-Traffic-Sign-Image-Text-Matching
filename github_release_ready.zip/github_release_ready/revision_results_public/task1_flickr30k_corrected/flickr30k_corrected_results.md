# Flickr30k corrected-results status

| Method | Dataset | R@1 | R@5 | R@10 | Status |
|---|---:|---:|---:|---:|---|
| Clean baseline | Clean | 25.75 | 53.91 | 67.12 | Manuscript-recorded; not independently verified |
| Clean baseline | Occluded | 16.01 | 39.50 | 52.80 | Manuscript-recorded; not independently verified |
| Retrained on occlusion | Occluded | 23.67 | 51.69 | 65.11 | Manuscript-recorded; checkpoint/config absent |
| TENT | Occluded | 15.79 | 38.87 | 51.76 | Manuscript-recorded; not independently verified |
| OATA | Occluded | **N/A** | **N/A** | **N/A** | Invalid row withdrawn pending non-leaking rerun |

The previous OATA row (`60.48 / 60.48 / 60.48`) is not a corrected result and should not remain in Table 7. No replacement numbers are invented. Once full similarity matrices are regenerated, run `evaluate_retrieval.py` and replace the N/A cells with independently computed image-to-text and/or text-to-image values, explicitly naming the split and direction.
