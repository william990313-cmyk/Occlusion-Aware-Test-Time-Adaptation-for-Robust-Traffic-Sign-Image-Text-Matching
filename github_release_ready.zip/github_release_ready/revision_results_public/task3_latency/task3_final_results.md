# Task 3 final results

All retrieval values use one dataset-level candidate pool of 1,512 images and 3,024 captions.

| Method | i2t R@1 | i2t R@5 | i2t R@10 | t2i R@1 | t2i R@5 | t2i R@10 | Timing |
|---|---:|---:|---:|---:|---:|---:|---|
| Baseline | 96.43 | 99.87 | 99.87 | 96.46 | 99.87 | 99.87 | 95.21 ms/batch |
| Pure TENT | 96.43 | 99.87 | 99.87 | 96.46 | 99.87 | 99.87 | 90.54 s total adaptation |
| OATA | 96.49 | 99.87 | 99.87 | 96.26 | 99.87 | 99.87 | 61 min 07 s total; 1.57 GB peak RSS |
| Lightweight pair reranker | 96.56 | 99.87 | 99.87 | 96.20 | 99.87 | 99.87 | not separately timed |
| OATA + lightweight pair reranker | **96.69** | 99.87 | 99.87 | 96.43 | 99.87 | 99.87 | 61 min 10.65 s incl. rerank |

The pair reranker is an MLP over dual-encoder embedding pairs, not a transformer cross-encoder. Pure TENT updates only 53 image-backbone BatchNorm affine parameter pairs with Adam (`lr=1e-5`) for 20 steps and freezes the text encoder. OATA is the available implementation combining BN adaptation, occlusion-invariance loss, and entropy loss. Every row satisfies `R@10 >= R@5 >= R@1`.
