# Hardware and environment

The reproducible hardware record must be filled by the WSL run (`nvidia-smi`, `python -c "import torch; ..."`). This Windows audit does not infer GPU model, CUDA runtime, or PyTorch build. Record OS/WSL version, GPU, VRAM, driver, CUDA, PyTorch, Transformers, torchvision, batch size, workers, and precision in the generated run log.

## Measured WSL environment

- GPU: NVIDIA GeForce RTX 3080 Ti
- VRAM: 12 GB
- Driver: 591.86
- PyTorch: 2.1.2+cu118
- CUDA: 11.8
- GPU count: 1
- Precision: FP32
- Batch size: 64
