# Latency protocol

Measure inference on the traffic-sign **test** split, using the full dataset-level candidate pool. Report median and p95 over timed batches after warm-up; exclude dataloader startup and checkpoint loading. Synchronize CUDA before and after each timed region. Report batch size, image count, caption count, device, and precision with every result.

Required rows are baseline, TENT, CE rerank, full OATA, and retrained model when assets exist. Missing methods are reported as unavailable rather than fabricated. Module regions are image encoder, text encoder, similarity/retrieval, adaptation overhead, and reranking overhead.
