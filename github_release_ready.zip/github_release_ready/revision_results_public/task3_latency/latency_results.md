# Latency results

No latency number is reported yet. The asset audit found the datasets, but the legacy traffic-sign checkpoint and model definition still need a WSL compatibility check. Reporting numbers before that check would be invalid.
