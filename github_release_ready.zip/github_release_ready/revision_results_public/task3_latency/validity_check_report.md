# Validity check

- Dataset-level pool: specified; test metadata has 1,512 images and two captions per image (3,024 captions).
- Batch-level retrieval: prohibited by protocol.
- CUDA synchronization: required by benchmark, not yet run.
- Checkpoint loading: pending WSL compatibility check.
- Training: not performed.
- Status: **partially resolved / blocked for numeric latency results**.

## TENT compatibility

- BatchNorm layers detected: 53
- BatchNorm location: image_encoder.backbone
- Standard BN-based TENT: supported
- Text encoder adaptation: disabled
- Image encoder adaptation: enabled
