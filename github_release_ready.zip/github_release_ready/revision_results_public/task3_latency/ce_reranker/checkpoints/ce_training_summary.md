Lightweight image-text pair MLP; epochs=5, negatives=1, best validation pair-order AUC=0.999947.
