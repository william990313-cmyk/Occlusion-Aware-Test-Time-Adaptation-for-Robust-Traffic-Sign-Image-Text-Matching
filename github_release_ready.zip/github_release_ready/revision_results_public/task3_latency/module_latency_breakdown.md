# Module latency breakdown

Pending the WSL benchmark. The timing harness must isolate image encoding, text encoding, similarity, TENT adaptation, and CE reranking, with CUDA synchronization around each region.
