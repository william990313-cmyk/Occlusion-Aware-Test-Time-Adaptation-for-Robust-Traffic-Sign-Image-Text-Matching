# Paper-ready latency table

| Method | Median latency (ms) | p95 (ms) | Throughput (img/s) | Peak VRAM (MB) |
|---|---:|---:|---:|---:|
| Baseline | pending | pending | pending | pending |
| TENT | pending | pending | pending | pending |
| CE rerank | pending | pending | pending | pending |
| OATA | pending | pending | pending | pending |
