# Task 3 final results

| Method | Status | Runtime | i2t R@1 | i2t R@5 | i2t R@10 | t2i R@1 | t2i R@5 | t2i R@10 |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| Baseline | Completed | 95.21 ms/batch | — | — | — | — | — | — |
| Non-pure TENT | Completed | ~20 × 24 adaptation batches | 96.43 | 99.87 | 99.87 | — | — | — |
| Pure TENT | Completed | 90.54 s total | 96.43 | 99.87 | 99.87 | 96.46 | 99.87 | 99.87 |
| CE rerank | Blocked | — | — | — | — | — | — | — |
| Full OATA | Blocked | — | — | — | — | — | — | — |

Pure TENT used dataset-level retrieval with 1,512 images and 3,024 captions. All Recall@K values satisfy `R@10 >= R@5 >= R@1`.
