# Simple re-ranking baseline comparison

| Method | i2t R@1 | i2t R@5 | i2t R@10 | t2i R@1 | t2i R@5 | t2i R@10 | Time (s) | Extra training | Monotonic |
|---|---:|---:|---:|---:|---:|---:|---:|---|---|
| no_reranking | 96.4286 | 99.8677 | 99.8677 | 96.4616 | 99.8677 | 99.8677 | 0.400 | no | True |
| similarity_only_topk | 96.4286 | 99.8677 | 99.8677 | 96.4616 | 99.8677 | 99.8677 | 0.377 | no | True |
| weighted_fusion_alpha_0.25 | 96.3624 | 99.8677 | 99.8677 | 96.4616 | 99.8677 | 99.8677 | 2.162 | no | True |
| weighted_fusion_alpha_0.5 | 96.2963 | 99.8677 | 99.8677 | 96.5608 | 99.8677 | 99.8677 | 2.441 | no | True |
| weighted_fusion_alpha_0.75 | 96.4286 | 99.8677 | 99.8677 | 96.4947 | 99.8677 | 99.8677 | 1.952 | no | True |
| pair_reranker | 96.5608 | 99.8677 | 99.8677 | 96.1971 | 99.8677 | 99.8677 | 2.081 | no | True |
| oata_pair_reranker | 96.6931 | 99.8677 | 99.8677 | 96.4286 | 99.8677 | 99.8677 | 2.230 | no | True |
