# Validity checks

- Candidate pool: complete dataset-level pool of 1,512 images and 3,024 captions.
- Fixed Top-K: 5, selected before Task 5 by the completed sensitivity experiment as the smallest saturated prefix.
- No re-ranking and similarity-only Top-K re-ranking produce the same order, as expected.
- Pair score for weighted fusion: sigmoid(pair-MLP logit), used to avoid mixing an arbitrary unbounded logit with cosine similarity.
- Extra training: none in Task 5; all pair-reranking rows reuse the previously trained pair-MLP checkpoint.
- Metrics: complete candidate rankings in both i2t and t2i; correct image-caption mapping; monotonicity confirmed for every row.
- Naming: the learned module is a lightweight image-text pair reranker, not the old invalid text-text CE script and not a transformer cross-encoder.
