# Task 9 environment audit

- Python: 3.10.20
- PyTorch: 2.1.2+cu118; CUDA runtime: 11.8
- GPU: NVIDIA GeForce RTX 3080 Ti
- `transformers`, `timm`, and `torchvision` are installed.
- `open_clip`, `clip`, and `sentence_transformers` are not installed.
- Selected backbone: Hugging Face `openai/clip-vit-base-patch32`.

The exact machine-readable audit is retained in `environment_audit_raw.json`.
