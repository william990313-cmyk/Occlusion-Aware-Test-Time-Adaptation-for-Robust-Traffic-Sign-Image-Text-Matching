# Supplementary backbone comparison (main traffic-sign test set)

All rows use the corrected dataset-level pool of 1,512 images and 3,024 captions. R@K values are percentages.

| Method | Training/adaptation status | i2t R@1 | i2t R@5 | i2t R@10 | t2i R@1 | t2i R@5 | t2i R@10 |
|---|---|---:|---:|---:|---:|---:|---:|
| ResNeXt50 + DistilBERT dual encoder | Domain-trained baseline | 96.43 | 99.87 | 99.87 | 96.46 | 99.87 | 99.87 |
| OATA + lightweight image-text pair reranker | Domain-trained encoder; OATA + Top-5 reranking | 96.69 | 99.87 | 99.87 | 96.43 | 99.87 | 99.87 |
| CLIP ViT-B/32 | Public zero-shot checkpoint; no domain fine-tuning | 0.60 | 3.17 | 5.36 | 1.03 | 4.50 | 8.20 |
| CLIP ViT-B/32 | Fine-tuned on main-dataset train split; validation-selected | 81.61 | 97.95 | 99.47 | 81.65 | 99.07 | 99.67 |

The zero-shot CLIP row is not a like-for-like replacement of the trained in-domain model; it documents that off-the-shelf general-purpose CLIP does not transfer effectively to this specialized traffic-sign task. Fine-tuning substantially closes that domain gap, but remains below the task-specific ResNeXt50 + DistilBERT baseline under the same strict candidate-pool protocol.
