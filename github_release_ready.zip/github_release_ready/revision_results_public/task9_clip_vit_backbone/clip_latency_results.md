# CLIP latency

| Image encoding | Text encoding | Similarity | Total | Image throughput | Peak GPU memory |
|---:|---:|---:|---:|---:|---:|
| 1324.65 ms | 1572.57 ms | 10.02 ms | 2907.24 ms | 1141.43 images/s | 773.58 MB |

Measured for full encoding of the 1,512-image / 3,024-caption test pool with batch size 64 on an RTX 3080 Ti.
