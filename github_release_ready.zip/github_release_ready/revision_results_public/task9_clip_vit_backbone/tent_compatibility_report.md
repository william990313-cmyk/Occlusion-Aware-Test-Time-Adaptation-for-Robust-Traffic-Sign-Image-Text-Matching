# TENT/OATA compatibility with CLIP ViT-B/32

`openai/clip-vit-base-patch32` contains **0 BatchNorm layers** and **51 LayerNorm layers**. Its visual encoder is a LayerNorm-based ViT and its text encoder is a LayerNorm-based Transformer. The complete module-name audit is preserved in `clip_norm_audit.json`.

The implemented TENT/OATA method updates BatchNorm affine parameters (gamma/beta) and uses batch-statistics behavior in the ResNeXt image encoder. Therefore, it is **not directly applicable** to this CLIP ViT backbone. Running the existing BN-TENT code would update no CLIP parameters and would not constitute a meaningful CLIP adaptation experiment.

No CLIP TENT or OATA result is reported. A future CLIP extension would require a separately designed and validated LayerNorm-/prompt-/feature-adaptation protocol, with its own hyperparameter selection and controls.
