# CLIP reranker result

No CLIP reranking result is reported. The existing legal image-text pair MLP is backbone-specific to the ResNeXt50 + DistilBERT embedding space, so applying it to CLIP outputs would not be valid without retraining.
