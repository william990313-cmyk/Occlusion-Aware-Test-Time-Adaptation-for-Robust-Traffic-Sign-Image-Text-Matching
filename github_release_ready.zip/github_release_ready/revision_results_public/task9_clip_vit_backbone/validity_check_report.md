# Validity checks

- **Dataset scope:** main traffic-sign test split only; no Flickr30k files were accessed.
- **Candidate pool:** dataset-level 1,512 images × 3,024 captions.
- **Recall validity:** both directions satisfy R@10 >= R@5 >= R@1 (CLIP i2t: 5.36 >= 3.17 >= 0.60; t2i: 8.20 >= 4.50 >= 1.03).
- **Fine-tuning split discipline:** CLIP was fine-tuned on 12,096 train images only. The 1,512-image validation split selected the best checkpoint by dataset-level i2t R@1 (81.8783%); the test split was not accessed by the training script.
- **CLIP test result:** the validation-selected checkpoint was evaluated once on test, obtaining i2t 81.61/97.95/99.47 and t2i 81.65/99.07/99.67. Both directions are monotonic.
- **TENT applicability:** model inspection found 0 BatchNorm and 51 LayerNorm layers. Existing BN-TENT/OATA was not run on CLIP.
- **Reranker validity:** the old invalid text-text reranker was not used. The existing valid pair-MLP was also not applied because it was trained in a different ResNeXt50 + DistilBERT embedding space.
- **Metric caveat:** `clip_baseline_metrics.json` contains an exploratory `mAP` field equal to MRR from the initial zero-shot exporter. It is not used in any Task 9 table or conclusion; Task 9 reports the verified Recall@K values only.
