# CLIP fine-tuning protocol

The public `openai/clip-vit-base-patch32` checkpoint will be fine-tuned only on the 12,096-image main traffic-sign training split. Each image is paired with one of its valid captions per epoch, sampled deterministically from the two available captions. The objective is symmetric CLIP image-to-text/text-to-image contrastive cross-entropy, so each batch contains one positive pair for every image.

The 1,512-image validation split is evaluated at dataset level after every epoch. The checkpoint with the best validation image-to-text R@1 is selected. The 1,512-image test split is not accessed during training or model selection, and is evaluated exactly once afterward against all 3,024 captions.

Recommended initial settings: 8 epochs, physical batch size 32, gradient accumulation 2 (effective batch size 64), AdamW with learning rate 5e-6 and weight decay 0.01, seed 42, mixed precision on CUDA. This is domain fine-tuning, not training CLIP from scratch.
