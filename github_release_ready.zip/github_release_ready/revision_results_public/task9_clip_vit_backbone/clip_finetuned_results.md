# Fine-tuned CLIP ViT-B/32: main traffic-sign test set

| Direction | R@1 | R@5 | R@10 |
|---|---:|---:|---:|
| Image-to-text | 81.6138 | 97.9497 | 99.4709 |
| Text-to-image | 81.6468 | 99.0741 | 99.6693 |

Candidate pool: 1,512 images × 3,024 captions at dataset level. The model was selected by validation dataset-level i2t R@1, not by test performance. Both directions satisfy R@10 >= R@5 >= R@1.

Test-set encoding latency: image 1150.03 ms, text 1650.72 ms, similarity 12.05 ms, total 2812.80 ms; peak GPU memory 773.45 MB.
