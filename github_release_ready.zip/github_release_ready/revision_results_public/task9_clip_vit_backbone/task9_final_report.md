# Task 9 final report: CLIP / ViT backbone supplementary experiment

## Protocol

The public `openai/clip-vit-base-patch32` checkpoint was first evaluated zero-shot, then fine-tuned only on the 12,096-image main-dataset training split. The 1,512-image validation split selected the highest strict dataset-level i2t R@1 checkpoint (81.8783% at epoch 8). The training code does not read the test split. The selected checkpoint was then evaluated once on the 1,512-image / 3,024-caption test pool.

## Results

| CLIP ViT-B/32 setting | i2t R@1 | i2t R@5 | i2t R@10 | t2i R@1 | t2i R@5 | t2i R@10 |
|---|---:|---:|---:|---:|---:|---:|
| Zero-shot public checkpoint | 0.60 | 3.17 | 5.36 | 1.03 | 4.50 | 8.20 |
| Fine-tuned, validation-selected | **81.61** | **97.95** | **99.47** | **81.65** | **99.07** | **99.67** |

Fine-tuned test encoding and similarity computation took 2,812.80 ms, with 773.45 MB peak GPU memory. The large increase over zero-shot confirms that the specialized traffic-sign domain requires in-domain adaptation. The fine-tuned CLIP result remains below the task-specific ResNeXt50 + DistilBERT dual encoder.

## Adaptation and reranking decision

The norm audit found 0 BatchNorm and 51 LayerNorm layers. The existing BN-TENT/OATA method consequently has no direct update targets in CLIP ViT-B/32, so no misleading BN-TENT result was generated. The existing lightweight pair MLP was not transferred to CLIP because it was trained on a different embedding distribution; no CLIP-specific reranker was trained.

## Status

**Fully resolved for the requested supplementary backbone comparison.** Task 9 now includes zero-shot and domain-fine-tuned CLIP/ViT results under the corrected protocol, plus a reproducible explanation of why the current BN-TENT/OATA implementation is architecture-specific and cannot be directly transferred to LayerNorm-based CLIP ViT.
