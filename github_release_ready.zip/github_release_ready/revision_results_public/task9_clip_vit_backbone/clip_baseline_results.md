# CLIP / ViT zero-shot dataset-level baseline

Model: Hugging Face `openai/clip-vit-base-patch32`; batch size 64; device `cuda:0`.

| Direction | R@1 | R@5 | R@10 | MRR |
|---|---:|---:|---:|---:|
| Image-to-text | 0.5952 | 3.1746 | 5.3571 | 2.5020 |
| Text-to-image | 1.0251 | 4.4974 | 8.2011 | 3.7122 |

Candidate pool: 1,512 images × 3,024 captions, evaluated at dataset level. All Recall@K values are percentages and satisfy R@10 >= R@5 >= R@1.

The raw JSON remains available in `clip_baseline_metrics.json`. Its exploratory `mAP` field is not reported because it duplicates MRR in the initial exporter rather than a separately validated multi-positive mAP computation.
