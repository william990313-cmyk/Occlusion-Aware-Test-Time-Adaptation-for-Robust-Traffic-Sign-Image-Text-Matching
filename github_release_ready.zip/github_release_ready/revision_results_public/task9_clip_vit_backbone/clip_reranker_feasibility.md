# CLIP reranker feasibility

The available lightweight image-text pair MLP was trained using embeddings from the task-specific ResNeXt50 + DistilBERT dual encoder. Although CLIP ViT-B/32 happens to export vectors of a compatible dimensionality, its embedding distribution, normalization, and image/text encoders are different.

Applying that checkpoint directly to CLIP embeddings would be an out-of-distribution use of the reranker and would not be a valid comparison. It was therefore deliberately not run. Training a CLIP-specific reranker would exceed Task 9's no-new-training constraint.

`clip_reranker_results.csv` records this result as not applicable rather than fabricating a number.
