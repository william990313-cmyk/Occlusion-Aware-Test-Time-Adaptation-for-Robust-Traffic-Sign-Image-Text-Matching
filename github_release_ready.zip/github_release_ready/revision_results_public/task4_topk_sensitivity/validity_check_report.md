# Validity checks

- Candidate pool: dataset-level, 1,512 images × 3,024 captions.
- Method: the existing OATA embeddings plus the already trained lightweight image-text pair MLP; no model was trained in Task 4.
- Prefix rule: only the Top-K prefix is reranked; every candidate after K remains in its original dual-encoder order.
- K settings: 1, 3, 5, 10, 20, and 50.
- Metric rule: both directions use the complete candidate list and the correct image-caption ground-truth mapping.
- Monotonicity: confirmed for every K and both directions.
- Timing: each reported value measures the full bidirectional reranking loop, including all 1,512 i2t and 3,024 t2i queries. It excludes OATA adaptation time.
