# Top-K sensitivity summary

The evaluation uses the fixed dataset-level pool of 1,512 images and 3,024 captions. OATA image embeddings were reranked by the already trained lightweight image-text pair MLP; no model was trained for this analysis.

- Every setting satisfies `R@10 >= R@5 >= R@1` for image-to-text and text-to-image.
- K=1 preserves the OATA retrieval order.
- i2t R@1 improves from 96.49 at K=1 to 96.56 at K=3 and 96.69 at K=5.
- The i2t result saturates at K=5: K=5, 10, 20, and 50 all give i2t R@1=96.69 and identical i2t R@5/R@10.
- t2i R@1 improves from 96.26 at K=1 to 96.43 at K=3 and remains unchanged for all larger K.
- Measured complete bidirectional reranking time ranges from 1.93 to 2.32 seconds. Minor non-monotonic variation is measurement noise from GPU scheduling/caching and Python overhead; it is not evidence that a larger K reduces computation.

K=5 is the preferred operating point: it attains the best measured retrieval result while reranking the smallest candidate prefix that reaches saturation.
