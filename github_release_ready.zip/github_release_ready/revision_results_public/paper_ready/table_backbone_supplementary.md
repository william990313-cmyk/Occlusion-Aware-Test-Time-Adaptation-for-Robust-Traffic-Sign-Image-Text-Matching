# Supplementary backbone comparison: CLIP ViT-B/32

All rows use the corrected main traffic-sign dataset-level test pool of 1,512 images × 3,024 captions. The public CLIP checkpoint was fine-tuned on the train split only; the validation split selected the best checkpoint, and test was evaluated afterward.

| Method | Training status | i2t R@1 | i2t R@5 | i2t R@10 | t2i R@1 | t2i R@5 | t2i R@10 |
|---|---|---:|---:|---:|---:|---:|---:|
| ResNeXt50 + DistilBERT dual encoder | Domain-trained baseline | 96.43 | 99.87 | 99.87 | 96.46 | 99.87 | 99.87 |
| OATA + lightweight pair reranker | Domain-trained encoder, OATA + Top-5 reranking | 96.69 | 99.87 | 99.87 | 96.43 | 99.87 | 99.87 |
| CLIP ViT-B/32 | Public zero-shot checkpoint | 0.60 | 3.17 | 5.36 | 1.03 | 4.50 | 8.20 |
| CLIP ViT-B/32 | Fine-tuned on train, validation-selected | 81.61 | 97.95 | 99.47 | 81.65 | 99.07 | 99.67 |

CLIP fine-tuning substantially reduces the zero-shot domain gap but remains below the task-specific dual encoder. The CLIP norm audit found 0 BatchNorm and 51 LayerNorm layers; the current BN-affine TENT/OATA method cannot be directly applied to this ViT backbone.

Source: `revision_results/task9_clip_vit_backbone/task9_final_report.md`.
