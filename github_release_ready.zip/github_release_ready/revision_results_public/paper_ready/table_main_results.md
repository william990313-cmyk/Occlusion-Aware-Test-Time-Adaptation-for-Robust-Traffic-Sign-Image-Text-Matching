# Main traffic-sign retrieval results

**Protocol.** Dataset-level evaluation over 1,512 image queries and 3,024 caption candidates. Each image has two valid captions; image-to-text is correct if either valid caption is retrieved within K. The lightweight pair reranker is an image-text pair MLP, not the old invalid text-text cross-encoder. All results use Top-K = 5 where reranking is applied.

| Method | i2t R@1 | i2t R@5 | i2t R@10 | t2i R@1 | t2i R@5 | t2i R@10 |
|---|---:|---:|---:|---:|---:|---:|
| Domain-trained dual encoder | 96.43 | 99.87 | 99.87 | **96.46** | 99.87 | 99.87 |
| Pure BN-TENT | 96.43 | 99.87 | 99.87 | 96.46 | 99.87 | 99.87 |
| Full OATA (BN-TENT + occlusion-invariance + entropy) | 96.49 | 99.87 | 99.87 | 96.26 | 99.87 | 99.87 |
| Dual encoder + lightweight pair reranker | 96.56 | 99.87 | 99.87 | 96.20 | 99.87 | 99.87 |
| Full OATA + lightweight pair reranker | **96.69** | 99.87 | 99.87 | 96.43 | 99.87 | 99.87 |

The retrieval pool is near saturation at R@5/R@10; therefore the remaining measurable differences appear mainly in R@1. Full OATA + the lightweight pair reranker yields the highest image-to-text R@1, while the un-reranked dual encoder has the highest text-to-image R@1 by a small margin.

Source: `revision_results/task3_main_latency_analysis/task3_final_results.md` and `revision_results/task5_reranking_baselines/reranking_baseline_results.csv`.
