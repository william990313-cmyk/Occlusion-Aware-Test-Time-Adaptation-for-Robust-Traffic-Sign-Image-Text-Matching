# Response-letter key points

## Retrieval-metric concern (Flickr30k Table 7)

We thank the reviewer for identifying the suspicious equal Recall@1/5/10 values. We audited the evaluation pipeline and found that the original OATA row was contaminated by a text-text reranking implementation that compared the query ground-truth caption to candidates and only reranked an initial Top-64 prefix. This procedure could collapse the rank distribution, yielding equal Recall@1/5/10 values. We replaced it with a modular dataset-level multi-positive evaluator, report both i2t and t2i directions, and withdrew the invalid `60.48/60.48/60.48` row.

## Evaluation protocol clarification

For the corrected Flickr30k evaluation, each image is evaluated against all 11,070 captions and each caption against all 2,214 images; all five captions associated with an image are treated as valid. For the main traffic-sign dataset, each image is evaluated against 3,024 captions and each caption against 1,512 images; both captions associated with an image are valid. Thus R@10 >= R@5 >= R@1 is explicitly verified for every reported result.

## Simpler re-ranking baseline

We added no-re-ranking, similarity-only Top-K, and weighted score-fusion baselines. Similarity-only re-ranking leaves ordering unchanged, and score fusion does not produce a consistent improvement. The valid lightweight image-text pair reranker gives a small i2t R@1 gain, with K=5 identified as the smallest saturated candidate prefix. We do not use the prior text-text reranker.

## Computational overhead and Top-K sensitivity

We added baseline latency, pure BN-TENT timing, full-OATA timing, and reranking time on an RTX 3080 Ti. Full OATA required 1 h 01 min 07 s for the 1,512-image test adaptation under the evaluated 20-step configuration. Top-K sensitivity for K=1,3,5,10,20,50 shows that performance saturates at K=5.

## Failure cases and limitations

We added 27 representative visual panels and a quantitative case inventory. The analysis shows both cases improved by adaptation/reranking and cases harmed by them. The principal limitations are severe loss of sign evidence, semantically similar descriptions, and initial Top-K candidate misses that a second-stage reranker cannot recover.

## Modern backbone supplementary experiment

We added a CLIP ViT-B/32 supplementary baseline under the same corrected test pool. Zero-shot CLIP is weak in this domain, while train-split fine-tuning improves i2t R@1 to 81.61% and t2i R@1 to 81.65%. We also audited the architecture: CLIP ViT-B/32 contains no BatchNorm layers, so our current BN-affine TENT/OATA implementation cannot be directly applied without redesigning the adaptation mechanism. We state this limitation explicitly rather than claiming backbone-agnostic applicability.
