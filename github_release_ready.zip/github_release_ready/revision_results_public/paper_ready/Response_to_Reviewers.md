# Response to Reviewers

**Manuscript title:** *Occlusion-Aware Test-Time Adaptation for Robust Traffic Sign Image-Text Matching*

Dear Editor and Reviewers,

We sincerely thank the Editor and the reviewers for their careful reading and constructive comments. We substantially revised the manuscript to improve evaluation correctness, methodological precision, reproducibility, and limitation transparency. In particular, we corrected the Flickr30k retrieval protocol and withdrew the invalid historical OATA row; clarified that the implemented second-stage module is a lightweight image--text pair reranker rather than a transformer cross-encoder; added dataset-level retrieval definitions, latency, Top-$K$ sensitivity, simpler reranking baselines, representative failure cases, and a CLIP ViT-B/32 supplementary experiment; and expanded the limitations and declarations.

The major revision points are as follows.

1. Flickr30k is now evaluated at dataset level (2,214 images $\times$ 11,070 captions) with all five captions per image treated as valid positives; the invalid `60.48/60.48/60.48` OATA row is withdrawn.
2. The main traffic-sign results now use a dataset-level pool of 1,512 images $\times$ 3,024 captions, with two valid captions per image and both i2t/t2i directions reported.
3. We clarify that the pair reranker is a 1,049,601-parameter MLP over image/text embedding interaction features, not a transformer cross-encoder.
4. We add measured latency, a Top-$K$ sensitivity analysis, simple reranking baselines, a failure-case inventory, and a historical occlusion-type appendix with an explicit protocol caveat.
5. We add zero-shot and fine-tuned CLIP ViT-B/32 references, and explicitly explain why the current BN-TENT/OATA code cannot be directly applied to its LayerNorm-based architecture.
6. We clarify that the benchmark contains **190 traffic-sign categories**, rather than 12 categories.

Below we provide point-by-point responses.

---

# Response to Reviewer 1

## Comment 1

**The motivation for introducing the cross-encoder re-ranking module could be further strengthened to better explain its role in improving image-text matching under occlusion.**

**Response:**

Thank you for this helpful comment. We revised both the terminology and the method description. The implemented module is not a transformer cross-encoder; it is now consistently described as a **lightweight image--text pair reranker**. TENT adapts only the image encoder's BatchNorm affine parameters ($\gamma,\beta$) to address batch-level visual distribution shift, while the text encoder remains frozen. The pair reranker then scores each image--text pair within the initial Top-$K$ prefix, allowing it to refine the top-rank order when a valid caption is already present in that prefix.

The revised manuscript specifies the input and output exactly: for 512-dimensional image and text embeddings, the reranker concatenates $[\mathbf v,\mathbf u,|\mathbf v-\mathbf u|,\mathbf v\odot\mathbf u]$ into a 2,048-dimensional feature, applies a 2,048$\rightarrow$512 linear layer, ReLU, dropout (0.1), and a 512$\rightarrow$1 linear layer, and outputs one scalar pair score. The MLP has 1,049,601 trainable parameters. It does not perform token-level cross-attention and cannot recover a correct candidate outside the initial Top-$K$ prefix.

**Changes in manuscript:** Section 3.1--3.4, especially Section 3.3, “Lightweight image--text pair reranking”; revised Fig. 1 caption; Section 2.5.

## Comment 2

**A comparison with a simpler re-ranking strategy would better demonstrate the effectiveness of the proposed cross-encoder module.**

**Response:**

Thank you. We added a direct comparison at Top-$K=5$ using the corrected dataset-level main traffic-sign pool (1,512 images $\times$ 3,024 captions): no reranking, similarity-only Top-$K$ reranking, weighted score fusion ($\alpha=0.25,0.50,0.75$), the lightweight pair reranker, and full OATA plus the pair reranker.

Similarity-only reranking is identical to no reranking, as expected. Weighted fusion does not provide a consistent bidirectional improvement. The pair reranker changes i2t R@1 from 96.43\% to 96.56\%, while t2i R@1 decreases from 96.46\% to 96.20\%. The best evaluated i2t setting is full OATA plus pair reranking: i2t R@1/R@5/R@10 = **96.69/99.87/99.87** and t2i R@1/R@5/R@10 = **96.43/99.87/99.87**. We describe this as a modest top-rank refinement because R@5 and R@10 are already near saturation.

**Changes in manuscript:** Section 4.5, “Simple reranking baseline comparison”; Table 5.

## Comment 3

**The performance under different occlusion types could be discussed in greater detail to provide more insights into robustness.**

**Response:**

Thank you. We retained and expanded the historical single-occlusion stress test covering fire, light glare, rain, fog, snow, and tree branches at three severity levels. It shows that strong rain (historical baseline/TENT R@1: 5.89/54.23) and strong fire (7.94/16.63) were particularly damaging, whereas strong fog was less damaging in that historical setting (69.41/91.40). We discuss that these synthetic patterns affect the image differently: rain/snow introduce texture-like interference, fog reduces contrast, high-intensity fire/glare can distort color cues, and tree branches can directly cover discriminative sign regions.

For transparency, we now label this table as **appendix-only historical analysis**. Its earlier protocol does not report both retrieval directions, R@10, candidate-pool size, or subset size, so it is not numerically mixed with the corrected dataset-level main results.

**Changes in manuscript:** Section 4.4, “Historical synthetic-occlusion stress test (appendix-only)”; Table 4; Section 5.4.

## Comment 4

**The computational overhead introduced by the re-ranking stage should be analyzed to support practicality.**

**Response:**

Thank you. We added measured computational-overhead results on an NVIDIA GeForce RTX 3080 Ti (12 GB), PyTorch 2.1.2+cu118, CUDA 11.8. At batch size 64, baseline dual-encoder inference has 95.21 ms median batch latency and 672.18 images/s throughput. Pure 20-step BN-TENT takes 90.54 s over the complete 1,512-image test set. The full available OATA configuration (BN-TENT plus occlusion-invariance and entropy objectives) takes **1 h 01 min 07 s**, with maximum resident-set size **1,644,624 KB**. The Top-5 pair reranker takes approximately **2.23 s** over the full candidate pool.

We explicitly state that the 1 h 01 min 07 s value is repeated full-test-set adaptation over 1,512 images, not single-query or per-frame streaming latency. We therefore no longer claim real-time deployment readiness; the primary overhead is the repeated adaptation pass, whereas the second-stage pair reranking is comparatively small.

**Changes in manuscript:** Section 4.7, “Latency and computational overhead”; Table 7; Section 5.2.

## Comment 5

**The comparison with the retrained model deserves further discussion to explain why test-time adaptation achieves superior performance.**

**Response:**

Thank you. We revised this discussion conservatively. The older claim that OATA universally outperforms retraining is no longer retained. The corrected main-dataset results show that the baseline is already near saturation at R@5/R@10, and the measurable changes are small and concentrated at R@1. We now state that OATA and pair reranking can modify selected top-ranked cases under the controlled benchmark, but can also harm some queries. Thus, the revised manuscript does not present test-time adaptation as a replacement for supervised retraining or robust pretraining.

**Changes in manuscript:** Section 4.6, “Corrected main traffic-sign results”; Section 5.1; Section 6.

## Comment 6

**A sensitivity analysis of the Top-$K$ candidate size would help verify the re-ranking strategy.**

**Response:**

Thank you. We evaluated $K\in\{1,3,5,10,20,50\}$ for full OATA plus pair reranking. i2t R@1 increases from 96.49\% at $K=1$ to 96.56\% at $K=3$ and 96.69\% at $K=5$; the results at $K=5,10,20,50$ are identical. The corresponding t2i R@1 is 96.43\% from $K=3$ onward. We therefore use **$K=5$**, the smallest saturated candidate prefix.

**Changes in manuscript:** Section 4.8, “Top-$K$ sensitivity”; Table 8; Section 3.3.

## Comment 7

**Including representative failure cases would help readers understand the limitations of the framework.**

**Response:**

Thank you. We added a corrected failure-case analysis with multiple valid captions handled explicitly. It identifies 12 baseline-wrong/OATA-correct cases, 18 baseline-wrong/full-framework-correct cases, 11 baseline-correct/OATA-wrong cases, 9 baseline-correct/reranker-wrong cases, 50 full-framework failures, and 2 initial-Top-5 candidate misses. We generated 27 representative panels and revised the qualitative-example caption accordingly.

The analysis shows three key limitations: heavily occluded sign regions can remove discriminative evidence; semantically close descriptions may still be confused; and reranking cannot recover a valid caption absent from the initial Top-5 prefix.

**Changes in manuscript:** Section 4.10, “Representative failure-case analysis”; revised Fig. 7 caption; Section 5.4. The detailed panels are included in the revision supplementary materials.

## Comment 8

**The manuscript could be polished by simplifying repetitive discussions and improving readability.**

**Response:**

Thank you. We shortened repetitive statements in the Abstract, Introduction, Experimental Results, Discussion, and Conclusion. We also revised the wording to avoid broad autonomous-driving claims and consistently use “lightweight image--text pair reranker” rather than “cross-encoder” for the implemented module.

**Changes in manuscript:** Abstract; Introduction; Sections 2--6.

---

# Response to Reviewer 2

## Comment 1: Suspicious results in Flickr30k Table 7

**The identical OATA Recall@1/Recall@5/Recall@10 values strongly suggest a metric or evaluation bug.**

**Response:**

We sincerely thank the reviewer for identifying this critical issue. Our audit confirmed that the previous OATA row was invalid. The prior reranking script did not conduct genuine dataset-level image--text reranking. It used the query image's ground-truth caption as one re-ranker input and compared it with candidate captions in only an initial Top-64 prefix. This created text--text self-matching leakage: whenever the ground-truth caption entered the Top-64 prefix, it could be promoted to rank 1. This rank collapse explains the identical 60.48\% values.

We removed that row and replaced the evaluator with a full-pool, multi-positive dataset-level metric implementation. The corrected Flickr30k pool contains 2,214 images and 11,070 captions, with five valid captions per image. All corrected rows satisfy R@10 $\geq$ R@5 $\geq$ R@1:

| Setting | i2t R@1/R@5/R@10 | t2i R@1/R@5/R@10 |
|---|---|---|
| Clean model $\rightarrow$ clean | 36.09 / 65.94 / 76.20 | 26.50 / 54.19 / 65.46 |
| Clean model $\rightarrow$ occluded | 34.24 / 63.46 / 73.62 | 25.62 / 52.14 / 63.37 |
| Retrained-on-occlusion $\rightarrow$ occluded | 34.91 / 64.23 / 74.71 | 25.64 / 52.20 / 63.33 |
| TENT-adapted clean model $\rightarrow$ occluded | 35.14 / 63.46 / 73.71 | 25.84 / 52.35 / 63.38 |

We now present Flickr30k as an auxiliary controlled-occlusion analysis. The valid pair reranker did not improve Flickr30k, so we do not use this benchmark to claim a positive OATA reranking effect.

**Changes in manuscript:** Section 4.11, “Corrected Flickr30k evaluation”; Table 9; Section 5.4; Section 6.

## Comment 2: Outdated backbone architectures

**The paper should discuss or supplement the ResNeXt/DistilBERT backbone with a CLIP/ViT experiment.**

**Response:**

Thank you. We added a supplementary `openai/clip-vit-base-patch32` experiment under the same corrected main-dataset test protocol. The public zero-shot CLIP checkpoint obtains i2t R@1/R@5/R@10 = 0.60/3.17/5.36 and t2i R@1/R@5/R@10 = 1.03/4.50/8.20. Fine-tuning only on the 12,096-image train split, selecting the checkpoint on the 1,512-image validation split, and evaluating afterward on the 1,512-image $\times$ 3,024-caption test pool yields i2t 81.61/97.95/99.47 and t2i 81.65/99.07/99.67.

The CLIP ViT-B/32 audit found 51 LayerNorm layers and no BatchNorm layers. Because the current OATA implementation updates BatchNorm affine parameters, applying it directly to CLIP would update no corresponding parameters and would not be a meaningful comparison. We therefore report CLIP as a supplementary backbone reference, not as backbone-agnostic OATA validation. The existing pair MLP was not applied to CLIP because it was trained in the ResNeXt--DistilBERT embedding space.

**Changes in manuscript:** Section 4.12, “Supplementary CLIP ViT-B/32 backbone check”; Table 10; Section 5.2; Section 5.4.

## Comment 3: Lack of latency and computational overhead analysis

**The paper should compare the inference time and memory overhead of the methods.**

**Response:**

Thank you. We added the measured latency and memory analysis described in our response to Reviewer 1, Comment 4. We report baseline batch latency and throughput, pure BN-TENT full-test adaptation time, full-OATA wall-clock time and maximum resident-set size, and Top-5 pair-reranking time. We restrict the table to measurements that were actually reproduced; we do not report an unsupported separate latency value for a historical retrained model. We also explicitly revise the manuscript to avoid any real-time deployment claim.

**Changes in manuscript:** Section 4.7; Table 7; Section 5.2.

## Comment 4: Over-reliance on 2D synthetic occlusions

**The authors should evaluate on natural real-world occlusions, such as TT100K or LISA.**

**Response:**

Thank you. We agree that 2D synthetic overlays cannot reproduce depth, parallax, complex illumination, camera dynamics, temporal effects, or natural physical occlusion. TT100K and LISA are valuable traffic-sign detection/classification resources, but they do not supply aligned natural-language image descriptions required for this image--text retrieval protocol. Using them directly would require a new benchmark-construction study: sign cropping, class-to-text design, candidate-pool construction, and a separately validated multi-positive retrieval protocol.

We therefore do not present synthetic results as evidence of real-world autonomous-driving readiness. The revised manuscript identifies naturally paired real-world occluded traffic-sign image--text data as a necessary future direction.

**Changes in manuscript:** Section 4.1; Section 5.3--5.4; Section 6.

## Comment 5: Limited dataset scale

**The base dataset contains only 12 traffic-sign types.**

**Response:**

We apologize that the original dataset description was unclear. The evaluated dataset is **not a 12-class dataset**; it contains **190 traffic-sign categories**. The reproducible partition used in the corrected evaluation contains 15,120 images and 30,240 descriptions, split into 12,096/1,512/1,512 train/validation/test images. The final test pool contains 1,512 image queries and 3,024 candidate captions, with two valid captions per image.

We revised the manuscript to state these facts explicitly. We nevertheless acknowledge that 190 categories remain smaller and less geographically diverse than a fully open-world multilingual driving vocabulary spanning countries, regions, and rare signs.

**Changes in manuscript:** Section 4.1, “Dataset and synthetic occlusion benchmark”; Section 3.4; Section 5.4; Section 6.

## Minor Comment 6: TENT instability in Fire-M

**The Fire-M degradation should be discussed.**

**Response:**

Thank you. We now identify Fire-M as an historical stress-test example where TENT did not uniformly improve the result. Fire-like synthetic patterns can introduce abnormal high-intensity colors and textures; under ambiguous inputs, entropy minimization can reinforce a confident but incorrect similarity distribution. We use this case as a caution against interpreting TENT as uniformly beneficial across all shifts.

**Changes in manuscript:** Section 4.4; Section 5.4.

## Minor Comment 7: Definition of “lightweight” cross-encoder

**The architecture, parameter count, and layer count should be specified.**

**Response:**

Thank you. As noted above, we corrected the terminology: this module is a lightweight image--text pair MLP, not a transformer cross-encoder. The revised method gives its exact 2,048$\rightarrow$512$\rightarrow$1 architecture, ReLU and dropout (0.1), 1,049,601 trainable parameters, input feature construction, scalar output, and Top-$K$-only role. It has no token-level cross-attention layers.

**Changes in manuscript:** Section 3.3.

## Minor Comment 8: Ablation-pool implementation details

**Implementation details for the listed TTA variants should be given for reproducibility.**

**Response:**

Thank you. Rather than retain a historical enhancement-pool table whose individual variants were not revalidated under the corrected dataset-level protocol, we removed those unsupported module-level claims from the main comparison. The revised manuscript reports only directly reproduced configurations and baselines: dual encoder, pure BN-TENT, full available OATA, simple reranking strategies, and the valid pair reranker. The method and setup now state the update parameters, frozen encoder, optimizer, learning rate, adaptation steps, batch size, candidate-pool definition, and reranker architecture.

**Changes in manuscript:** Sections 3.2--3.4; Section 4.2; Table 5; Table 6.

## Minor Comment 9: Equation 3 and candidate-pool definition

**The softmax equation appears batch-level, whereas retrieval should use the full validation/test candidate pool.**

**Response:**

Thank you. We revised the notation to distinguish the batch-local entropy objective from final retrieval evaluation. The softmax in the TENT loss is formed over batch-local candidate scores solely to drive adaptation. Final Recall@K is then computed from full similarity matrices at dataset level: 1,512 images $\times$ 3,024 captions for the main benchmark and 2,214 images $\times$ 11,070 captions for Flickr30k. Multiple valid captions are handled explicitly in both directions.

**Changes in manuscript:** Section 3.2; Equation (3); Section 3.4; Section 4.2.

## Minor Comment 10: Formatting

**Ensure mathematical variables are consistently formatted.**

**Response:**

Thank you. We checked and harmonized the notation for image/text embeddings, score matrices, probability distributions, candidate sets, and Top-$K$ values. We also distinguish batch-local adaptation notation from the dataset-level candidate pool.

**Changes in manuscript:** Sections 3--4 and equations therein.

---

# Additional Editorial Requirement: Declarations

**Response:**

We added a separate Declarations section containing Funding, Competing interests, Ethical approval, Consent to participate, Consent to publish, Author contributions, Data availability, and Code availability. The ethical-approval wording follows the requested form: “This article does not contain any studies involving human participants or animals performed by any of the authors.”

**Changes in manuscript:** Declarations section.

---

# Closing Statement

We again thank the Editor and reviewers for their constructive comments. The revised manuscript corrects the evaluation issue, makes the method and candidate-pool protocol explicit, adds the requested efficiency, reranking, sensitivity, failure-case, and backbone analyses, and substantially narrows claims to the evidence supported by the controlled synthetic-occlusion experiments.
