# Appendix: historical synthetic occlusion stress test

> **Protocol warning.** This table is retained only as a historical appendix. The original manuscript records do not provide retrieval direction, R@10, candidate-pool size, or subset size. These values must not be mixed with, or directly compared to, the corrected dataset-level tables above.

| Strong synthetic occlusion | Historical baseline R@1 | Historical TENT R@1 | Historical gain |
|---|---:|---:|---:|
| Fire | 7.94 | 16.63 | 8.70 |
| Light glare | 48.02 | 77.91 | 29.89 |
| Rain | 5.89 | 54.23 | 48.35 |
| Fog | 69.41 | 91.40 | 21.99 |
| Snow | 26.12 | 54.66 | 28.54 |
| Tree branch | 16.34 | 38.53 | 22.19 |

Source: `revision_results/task7_occlusion_type_analysis/paper_ready_occlusion_type_table.md`.
