# Flickr30k corrected dataset-level retrieval results

**Protocol.** Dataset-level pool of 2,214 images and 11,070 captions (five valid captions per image). Results report both retrieval directions and use all valid captions. The previous Table 7 OATA values `60.48 / 60.48 / 60.48` are invalid and must be withdrawn: the old text-text reranking code leaked the ground-truth caption and gated candidates at Top-64, which collapsed the rank distribution.

| Setting | i2t R@1 | i2t R@5 | i2t R@10 | t2i R@1 | t2i R@5 | t2i R@10 |
|---|---:|---:|---:|---:|---:|---:|
| Clean model → clean test | 36.09 | 65.94 | 76.20 | 26.50 | 54.19 | 65.46 |
| Clean model → occluded test | 34.24 | 63.46 | 73.62 | 25.62 | 52.14 | 63.37 |
| Retrained-on-occlusion model → occluded test | 34.91 | 64.23 | **74.71** | 25.64 | 52.20 | 63.33 |
| TENT-adapted clean model → occluded test | **35.14** | 63.46 | 73.71 | **25.84** | **52.35** | **63.38** |

The valid lightweight pair reranker did not improve the Flickr30k result; it should not be used to support a positive OATA claim on this benchmark. No full-OATA Flickr30k row is reported here, because the historical `60.48/60.48/60.48` row is invalid and no independent full-OATA rerun under the corrected protocol is available.

Source: `revision_results/task1_flickr30k_metric_check/*_correct_metrics.json`, `tent_eval/tent_flickr30k_correct_metrics.json`, and `revision_results/task1c_flickr30k_ce_reranker/task1c_final_report.md`.
