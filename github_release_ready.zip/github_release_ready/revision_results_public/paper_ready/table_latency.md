# Computational overhead and latency

**Hardware.** NVIDIA GeForce RTX 3080 Ti (12 GB), PyTorch 2.1.2+cu118, CUDA 11.8. Main traffic-sign test split: 1,512 images; batch size 64 for baseline inference and adaptation evaluation.

| Component / method | Measurement | Result |
|---|---|---:|
| Baseline dual encoder | Median batch latency | 95.21 ms / batch |
| Baseline dual encoder | P95 batch latency | 95.64 ms / batch |
| Baseline dual encoder | Throughput | 672.18 images/s |
| Pure BN-TENT (20 steps) | Full-test adaptation wall time | 90.54 s |
| Full OATA (20 steps) | Full-test adaptation wall time | 1 h 01 min 07 s |
| Full OATA | Maximum resident-set size | 1,644,624 KB (about 1.57 GB) |
| Lightweight pair reranker, Top-5 | Full-pool reranking time | about 2.23 s |
| CLIP ViT-B/32 fine-tuned | Image + text encoding + similarity | 2.813 s |
| CLIP ViT-B/32 fine-tuned | Peak GPU memory | 773.45 MB |

The OATA timing includes its available BN adaptation, occlusion-invariance, and entropy objectives. The reranker time is a separate second-stage measurement and should not be presented as part of the baseline encoder forward-pass time.

Source: `revision_results/task3_main_latency_analysis/` and `revision_results/task9_clip_vit_backbone/clip_finetuned_test/clip_finetuned_test_metrics.json`.
