# Top-K sensitivity of OATA + lightweight pair reranking

Dataset-level candidate pool: 1,512 images × 3,024 captions. The reranker receives only the initial Top-K candidates from the dual encoder.

| K | i2t R@1 | i2t R@5 | i2t R@10 | t2i R@1 | t2i R@5 | t2i R@10 | Reranking time (s) |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 1 | 96.49 | 99.87 | 99.87 | 96.26 | 99.87 | 99.87 | 2.00 |
| 3 | 96.56 | 99.87 | 99.87 | 96.43 | 99.87 | 99.87 | 2.06 |
| **5** | **96.69** | 99.87 | 99.87 | **96.43** | 99.87 | 99.87 | 2.31 |
| 10 | 96.69 | 99.87 | 99.87 | 96.43 | 99.87 | 99.87 | 1.93 |
| 20 | 96.69 | 99.87 | 99.87 | 96.43 | 99.87 | 99.87 | 1.93 |
| 50 | 96.69 | 99.87 | 99.87 | 96.43 | 99.87 | 99.87 | 2.32 |

Performance saturates at K=5; larger candidate prefixes did not improve retrieval. K=5 is therefore the reported operating point.

Source: `revision_results/task4_topk_sensitivity/topk_sensitivity_results.csv`.
