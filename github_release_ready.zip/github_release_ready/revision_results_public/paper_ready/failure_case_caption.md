# Figure caption: representative success and failure cases

Representative cases on the main traffic-sign test set under the corrected dataset-level retrieval protocol. OATA can promote a valid description for some occlusion-shifted queries, and the lightweight image-text pair reranker can further correct cases in which a valid caption is already contained in the initial Top-5 candidate prefix. The examples also show limitations: the framework may choose a semantically close but incorrect description when key sign evidence is unavailable, and Top-5 reranking cannot recover a valid caption that is absent from the initial candidate prefix.

The corresponding 27 validated panels are available in `revision_results/task6_failure_cases/failure_case_panels/`.
