# Comparison with simpler re-ranking strategies

All methods use the main traffic-sign dataset-level candidate pool (1,512 images × 3,024 captions) and Top-K = 5. Weighted fusion uses `alpha × dual-encoder similarity + (1 − alpha) × sigmoid(pair-MLP score)`.

| Method | i2t R@1 | i2t R@5 | i2t R@10 | t2i R@1 | t2i R@5 | t2i R@10 | Time (s) |
|---|---:|---:|---:|---:|---:|---:|---:|
| No re-ranking | 96.43 | 99.87 | 99.87 | **96.46** | 99.87 | 99.87 | 0.40 |
| Similarity-only Top-5 | 96.43 | 99.87 | 99.87 | **96.46** | 99.87 | 99.87 | 0.38 |
| Fusion, alpha = 0.25 | 96.36 | 99.87 | 99.87 | **96.46** | 99.87 | 99.87 | 2.16 |
| Fusion, alpha = 0.50 | 96.30 | 99.87 | 99.87 | 96.56 | 99.87 | 99.87 | 2.44 |
| Fusion, alpha = 0.75 | 96.43 | 99.87 | 99.87 | 96.49 | 99.87 | 99.87 | 1.95 |
| Lightweight image-text pair reranker | 96.56 | 99.87 | 99.87 | 96.20 | 99.87 | 99.87 | 2.08 |
| OATA + lightweight image-text pair reranker | **96.69** | 99.87 | 99.87 | 96.43 | 99.87 | 99.87 | 2.23 |

Similarity-only Top-K leaves the ordering unchanged, as expected. Score fusion does not yield a consistent improvement. The pair reranker provides a small i2t R@1 gain, whereas the pool is already saturated at R@5/R@10; this limits observable gains. “Extra training” is **no** for this comparison because it uses the already trained lightweight pair MLP.

Source: `revision_results/task5_reranking_baselines/reranking_baseline_results.csv`.
