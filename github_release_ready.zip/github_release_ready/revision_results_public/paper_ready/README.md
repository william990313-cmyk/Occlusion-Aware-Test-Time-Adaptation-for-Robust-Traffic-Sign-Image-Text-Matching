# Paper-ready revision materials

These files are manuscript- and rebuttal-ready consolidations of the validated revision results. They do not replace the detailed reproducibility materials retained under each `revision_results/task*` directory.

All retrieval values are percentages. Unless stated otherwise, results use the corrected dataset-level protocol with all valid captions per image and satisfy R@10 >= R@5 >= R@1.

| File | Intended use |
|---|---|
| `table_main_results.md` | Main traffic-sign retrieval table |
| `table_flickr30k_corrected.md` | Corrected Flickr30k table and withdrawal note |
| `table_latency.md` | Computational-overhead/latency table |
| `table_topk_sensitivity.md` | Top-K sensitivity table |
| `table_reranking_baselines.md` | Simpler re-ranking baseline comparison |
| `table_occlusion_type_appendix.md` | Historical occlusion-type appendix table, with protocol caveat |
| `table_backbone_supplementary.md` | Zero-shot and fine-tuned CLIP ViT-B/32 supplementary comparison |
| `failure_case_caption.md` | Figure caption for Task 6 panels |
| `discussion_limitations.md` | Discussion-ready limitation paragraphs |
| `response_key_points.md` | Response-letter key points |
